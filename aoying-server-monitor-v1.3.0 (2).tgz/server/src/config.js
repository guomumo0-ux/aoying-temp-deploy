export function loadConfig(env = process.env) {
  const required = ['INGEST_TOKEN', 'ADMIN_PASSWORD_HASH', 'SESSION_SECRET', 'DB_PATH'];
  for (const key of required) if (!env[key]) throw new Error(`Missing required configuration: ${key}`);
  if (env.INGEST_TOKEN.length < 32) throw new Error('INGEST_TOKEN must be at least 32 characters');
  if (env.SESSION_SECRET.length < 32) throw new Error('SESSION_SECRET must be at least 32 characters');
  if (!/^[^:]+:[0-9a-f]{64}$/.test(env.ADMIN_PASSWORD_HASH)) throw new Error('ADMIN_PASSWORD_HASH must use salt:derivedKeyHex format');
  if (!!env.TELEGRAM_BOT_TOKEN !== !!env.TELEGRAM_CHAT_ID) throw new Error(env.TELEGRAM_BOT_TOKEN ? 'Missing required configuration: TELEGRAM_CHAT_ID' : 'Missing required configuration: TELEGRAM_BOT_TOKEN');
  if (env.TELEGRAM_CHAT_ID && !/^-?\d+$/.test(env.TELEGRAM_CHAT_ID)) throw new Error('TELEGRAM_CHAT_ID must be numeric');
  const telegram = env.TELEGRAM_BOT_TOKEN ? { botToken: env.TELEGRAM_BOT_TOKEN, chatId: env.TELEGRAM_CHAT_ID } : null;
  return { ingestToken: env.INGEST_TOKEN, adminPasswordHash: env.ADMIN_PASSWORD_HASH, sessionSecret: env.SESSION_SECRET, dbPath: env.DB_PATH, telegram, host: '127.0.0.1', port: 8788 };
}
