import { verifyBearer, verifyAdminPassword, createSession, verifySession } from './auth.js';
import { MAX_BODY_BYTES, validateIngest } from './validate.js';
import { activateTelegram, writeIngest } from './db.js';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
import { createHash } from 'node:crypto';
const PUBLIC_DIR = join(dirname(fileURLToPath(import.meta.url)), '../public');

export function computeHealth(lastHeartbeat, lastSnapshot, now = new Date().toISOString()) {
  const age = value => value && Number.isFinite(Date.parse(value)) && Number.isFinite(Date.parse(now)) ? Date.parse(now) - Date.parse(value) : Infinity;
  const heartbeatAge = age(lastHeartbeat), snapshotAge = age(lastSnapshot);
  return { collector: heartbeatAge === Infinity ? 'never_seen' : heartbeatAge > 60000 ? 'interrupted' : 'healthy', snapshot: snapshotAge === Infinity ? 'missing' : snapshotAge > 90000 ? 'stale' : 'fresh' };
}
function response(statusCode, body, headers = {'content-type':'application/json'}) { return { statusCode, headers, body: typeof body === 'string' ? body : JSON.stringify(body) }; }
function cookieValue(header, name) { return String(header ?? '').split(';').map(v => v.trim()).find(v => v.startsWith(`${name}=`))?.slice(name.length + 1); }
function sessionCookie(token) { return `monitor_session=${token}; Max-Age=43200; HttpOnly; Secure; SameSite=Strict; Path=/`; }
function tokenHash(token) { return createHash('sha256').update(token).digest('hex'); }
export function listRecentEvents(db, now = Date.now()) {
  const cutoff = new Date(now - 48 * 60 * 60 * 1000).toISOString();
  const upper = new Date(now + 5 * 60 * 1000).toISOString();
  return db.prepare('SELECT * FROM events WHERE trade_time IS NOT NULL AND trade_time >= ? AND trade_time <= ? ORDER BY trade_time DESC LIMIT 500').all(cutoff, upper);
}

export function buildApp(config, db) {
  const route = async (req) => {
    const staticFiles = {'/':'index.html','/index.html':'index.html','/login.html':'login.html','/app.js':'app.js','/styles.css':'styles.css'};
    if (req.method === 'GET' && staticFiles[req.url]) {
      const file = staticFiles[req.url];
      const type = file.endsWith('.html') ? 'text/html; charset=utf-8' : file.endsWith('.css') ? 'text/css; charset=utf-8' : 'text/javascript; charset=utf-8';
      return response(200, await readFile(join(PUBLIC_DIR, file), 'utf8'), {'content-type': type});
    }
    if (req.method === 'POST' && req.url === '/login') {
      let raw = ''; for await (const chunk of req) raw += chunk;
      let body; try { body = JSON.parse(raw); } catch { body = {}; }
      if (!await verifyAdminPassword(body.password, config.adminPasswordHash)) return response(401, {error:'unauthorized'});
      const token = createSession(config.sessionSecret); db.prepare('INSERT INTO sessions(token_hash, expires_at) VALUES(?,?)').run(tokenHash(token), Date.now() + 12 * 60 * 60 * 1000);
      return response(200, {ok:true}, {'content-type':'application/json', 'set-cookie': sessionCookie(token)});
    }
    if (req.method === 'POST' && req.url === '/logout') { const token = cookieValue(req.headers.cookie, 'monitor_session'); if (token) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(token)); return response(200, {ok:true}, {'content-type':'application/json', 'set-cookie':'monitor_session=; Max-Age=0; HttpOnly; Secure; SameSite=Strict; Path=/'}); }
    if (req.method === 'GET' && (req.url === '/api/v1/dashboard' || req.url === '/api/v1/events')) {
      const token = cookieValue(req.headers.cookie, 'monitor_session'); db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
      if (!verifySession(token, config.sessionSecret) || !db.prepare('SELECT 1 FROM sessions WHERE token_hash=? AND expires_at > ?').get(tokenHash(token ?? ''), Date.now())) return response(401, {error:'unauthorized'});
      if (req.url.endsWith('events')) return response(200, {events: listRecentEvents(db)});
      const heartbeat = db.prepare('SELECT observed_at FROM heartbeats ORDER BY observed_at DESC LIMIT 1').get()?.observed_at ?? null;
      const snapshot = db.prepare('SELECT observed_at FROM snapshots ORDER BY observed_at DESC LIMIT 1').get()?.observed_at ?? null;
      const positions = db.prepare('SELECT payload FROM positions ORDER BY observed_at DESC LIMIT 100').all().map(row => JSON.parse(row.payload));
      return response(200, {health: computeHealth(heartbeat, snapshot), lastHeartbeat: heartbeat, lastSnapshot: snapshot, positions});
    }
    if (req.method === 'POST' && req.url === '/api/v1/ingest/activate') {
      if (!verifyBearer(req.headers.authorization, config.ingestToken)) return response(401, {error:'unauthorized'});
      try { activateTelegram(db); return response(200, {ok:true}); } catch { return response(500, {error:'storage_error'}); }
    }
    if (req.method !== 'POST' || req.url !== '/api/v1/ingest') return response(404, {error:'not_found'});
    if (!verifyBearer(req.headers.authorization, config.ingestToken)) return response(401, {error:'unauthorized'});
    let raw = ''; for await (const chunk of req) { raw += chunk; if (Buffer.byteLength(raw) > MAX_BODY_BYTES) return response(413, {error:'payload_too_large'}); }
    let body; try { body = JSON.parse(raw); } catch { return response(400, {error:'invalid_json'}); }
    const error = validateIngest(body); if (error) return response(400, {error});
    try { writeIngest(db, body); return response(200, {ok:true}); } catch { return response(500, {error:'storage_error'}); }
  };
  const handler = async (req, res) => { const out = await route(req); res.writeHead(out.statusCode, out.headers); res.end(out.body); };
  return { handler, listen: (...args) => import('node:http').then(({createServer}) => new Promise(resolve => { const server = createServer(handler); server.listen(...args, () => resolve(server)); })), inject: async ({method, url, headers = {}, payload = {}}) => { const {PassThrough} = await import('node:stream'); const req = new PassThrough(); req.method=method; req.url=url; req.headers=Object.fromEntries(Object.entries(headers).map(([k,v])=>[k.toLowerCase(),v])); const promise=route(req); req.end(method === 'GET' ? undefined : JSON.stringify(payload)); const out=await promise; return {statusCode:out.statusCode, headers:out.headers, body:out.body, json:()=>JSON.parse(out.body)}; } };
}
