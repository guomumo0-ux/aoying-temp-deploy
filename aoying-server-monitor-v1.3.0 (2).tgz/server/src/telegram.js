const RETRIES_MS = [5000, 15000, 30000, 60000, 300000];
const ACTIONS = { open: '开仓', increase: '加仓', reduce: '减仓', close: '平仓' };
const SIDES = { long: '做多', short: '做空' };

function value(value) {
  return value === null || value === undefined ? '—' : String(value);
}

function beijingTime(iso) {
  if (!Number.isFinite(Date.parse(iso))) return '—';
  return new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(new Date(iso));
}

export function formatTelegramMessage(event) {
  return [
    '🔔 熬鹰资本新交易',
    `时间：${beijingTime(event.trade_time ?? event.tradeTime)}`,
    `交易对：${value(event.symbol)}`,
    `动作：${ACTIONS[event.action] ?? event.action}`,
    `方向：${SIDES[event.side] ?? event.side}`,
    `价格：${value(event.price)}`,
    `数量：${value(event.quantity)}`,
    `名义价值：${value(event.notional_usdt ?? event.notionalUsdt)} USDT`
  ].join('\n');
}

async function sendTelegram(config, text, fetchFn) {
  const response = await fetchFn(`https://api.telegram.org/bot${config.botToken}/sendMessage`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: config.chatId, text, disable_web_page_preview: true }) });
  if (!response.ok) throw new Error('send_failed');
  const body = await response.json();
  if (!body?.ok) throw new Error('send_failed');
}

export async function processTelegramOutbox(db, config, options = {}) {
  const now = options.now ?? Date.now;
  const fetchFn = options.fetchFn ?? fetch;
  const nowMs = now();
  const nowIso = new Date(nowMs).toISOString();
  const rows = db.prepare("SELECT o.event_id,o.attempts,e.* FROM telegram_outbox o JOIN events e ON e.event_id=o.event_id WHERE o.state='pending' AND o.next_attempt_at <= ? ORDER BY o.created_at LIMIT 10").all(nowIso);
  let sent = 0, failed = 0;
  for (const row of rows) {
    try {
      await sendTelegram(config, formatTelegramMessage(row), fetchFn);
      db.prepare("UPDATE telegram_outbox SET state='sent',sent_at=?,last_error=NULL WHERE event_id=?").run(nowIso, row.event_id);
      sent += 1;
    } catch {
      const attempts = row.attempts + 1;
      const delay = RETRIES_MS[Math.min(attempts - 1, RETRIES_MS.length - 1)];
      db.prepare("UPDATE telegram_outbox SET attempts=?,next_attempt_at=?,last_error='send_failed' WHERE event_id=?").run(attempts, new Date(nowMs + delay).toISOString(), row.event_id);
      failed += 1;
    }
  }
  return { sent, failed };
}

export function startTelegramWorker(db, config, options = {}) {
  const run = () => processTelegramOutbox(db, config, options).catch(() => {});
  void run();
  const timer = setInterval(run, options.intervalMs ?? 5000);
  timer.unref?.();
  return timer;
}
