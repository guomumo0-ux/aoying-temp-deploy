import { timingSafeEqual, scrypt, createHmac, randomBytes } from 'node:crypto';
import { promisify } from 'node:util';
const scryptAsync = promisify(scrypt);
export function verifyBearer(header, expected) {
  if (typeof header !== 'string' || !header.startsWith('Bearer ') || typeof expected !== 'string') return false;
  const actual = Buffer.from(header.slice(7));
  const wanted = Buffer.from(expected);
  return actual.length === wanted.length && timingSafeEqual(actual, wanted);
}
export async function verifyAdminPassword(password, encoded) {
  if (typeof password !== 'string' || typeof encoded !== 'string') return false;
  const [salt, expectedHex] = encoded.split(':');
  if (!salt || !/^[a-f0-9]{64}$/.test(expectedHex ?? '')) return false;
  const actual = await scryptAsync(password, salt, 32);
  const expected = Buffer.from(expectedHex, 'hex');
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
export function createSession(sessionSecret, now = Date.now()) {
  const payload = `${now}.${randomBytes(16).toString('hex')}`;
  const sig = createHmac('sha256', sessionSecret).update(payload).digest('hex');
  return `${payload}.${sig}`;
}
export function verifySession(token, sessionSecret, now = Date.now()) {
  if (typeof token !== 'string') return false;
  const parts = token.split('.');
  if (parts.length !== 3) return false;
  const [issued, nonce, sig] = parts;
  const expected = createHmac('sha256', sessionSecret).update(`${issued}.${nonce}`).digest('hex');
  if (sig.length !== expected.length || !timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
  const issuedAt = Number(issued);
  return Number.isFinite(issuedAt) && now - issuedAt >= 0 && now - issuedAt <= 12 * 60 * 60 * 1000;
}
