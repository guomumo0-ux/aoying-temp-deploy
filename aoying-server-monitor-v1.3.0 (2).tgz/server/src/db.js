import { DatabaseSync } from 'node:sqlite';
export function createDb(path) {
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS heartbeats (observed_at TEXT NOT NULL, parser_version TEXT); CREATE TABLE IF NOT EXISTS events (event_id TEXT PRIMARY KEY, symbol TEXT, side TEXT, action TEXT, price REAL, quantity REAL, notional_usdt REAL, trade_time TEXT, raw_text_hash TEXT, observed_at TEXT); CREATE TABLE IF NOT EXISTS snapshots (observed_at TEXT PRIMARY KEY, parser_version TEXT); CREATE TABLE IF NOT EXISTS positions (position_id TEXT PRIMARY KEY, payload TEXT NOT NULL, observed_at TEXT NOT NULL); CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, expires_at INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL); CREATE TABLE IF NOT EXISTS telegram_outbox (event_id TEXT PRIMARY KEY, state TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, next_attempt_at TEXT NOT NULL, created_at TEXT NOT NULL, sent_at TEXT, last_error TEXT);`);
  return db;
}
export function activateTelegram(db, now = new Date().toISOString()) {
  db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES('telegram_enabled_at',?)").run(now);
  return db.prepare("SELECT value FROM settings WHERE key='telegram_enabled_at'").get().value;
}
export function writeIngest(db, body) {
  db.exec('BEGIN');
  try {
    const observed = body.heartbeat.observedAt;
    db.prepare('INSERT INTO heartbeats(observed_at, parser_version) VALUES(?, ?)').run(observed, body.heartbeat?.parserVersion ?? null);
    const event = db.prepare('INSERT OR IGNORE INTO events(event_id,symbol,side,action,price,quantity,notional_usdt,trade_time,raw_text_hash,observed_at) VALUES(?,?,?,?,?,?,?,?,?,?)');
    const enabledAt = db.prepare("SELECT value FROM settings WHERE key='telegram_enabled_at'").get()?.value ?? null;
    const queuedAt = new Date(Date.parse(observed)).toISOString();
    const queue = db.prepare("INSERT OR IGNORE INTO telegram_outbox(event_id,state,attempts,next_attempt_at,created_at) VALUES(?,'pending',0,?,?)");
    for (const e of body.events) {
      const inserted = event.run(e.event_id,e.symbol??null,e.side,e.action,e.price??null,e.quantity??null,e.notionalUsdt??null,e.tradeTime,e.rawTextHash??null,observed);
      if (inserted.changes && enabledAt && e.tradeTime && Date.parse(e.tradeTime) >= Date.parse(enabledAt)) queue.run(e.event_id, queuedAt, queuedAt);
    }
    db.prepare('INSERT OR REPLACE INTO snapshots(observed_at,parser_version) VALUES(?,?)').run(observed, body.heartbeat?.parserVersion ?? null);
    const pos = db.prepare('INSERT OR REPLACE INTO positions(position_id,payload,observed_at) VALUES(?,?,?)');
    body.positions.forEach((p, i) => pos.run(p.position_id ?? p.positionId ?? `position-${i}`, JSON.stringify(p), observed));
    db.exec('COMMIT');
  } catch (error) { db.exec('ROLLBACK'); throw error; }
}
