import { ACTIONS, SIDES } from '../../shared/contracts.js';
const MAX = 64 * 1024;
const iso = value => typeof value === 'string' && !Number.isNaN(Date.parse(value));
function timeOk(value, now = Date.now()) { const t = Date.parse(value); return t >= now - 48 * 60 * 60 * 1000 && t <= now + 300000; }
export function validateIngest(body, now = Date.now()) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) return 'body must be an object';
  if (!Array.isArray(body.events) || !Array.isArray(body.positions)) return 'events and positions are required arrays';
  if (body.events.length > 100 || body.positions.length > 100) return 'too many records';
  if (!body.heartbeat || typeof body.heartbeat !== 'object') return 'heartbeat is required';
  if (typeof body.heartbeat.sourceId !== 'string' || !body.heartbeat.sourceId || typeof body.heartbeat.parserVersion !== 'string' || !body.heartbeat.parserVersion || typeof body.heartbeat.status !== 'string' || !body.heartbeat.status) return 'invalid heartbeat';
  if (!iso(body.heartbeat.observedAt) || !timeOk(body.heartbeat.observedAt, now)) return 'invalid heartbeat observedAt';
  for (const event of body.events) {
    if (!event || typeof event.event_id !== 'string' || !event.event_id) return 'invalid event_id';
    if (!SIDES.includes(event.side) || !ACTIONS.includes(event.action)) return 'invalid event enum';
    if (event.tradeTime !== null && (!iso(event.tradeTime) || !timeOk(event.tradeTime, now))) return 'invalid tradeTime';
  }
  const allowedPositionFields = new Set(['position_id', 'positionId', 'symbol', 'side', 'action', 'quantity', 'entryPrice', 'markPrice', 'unrealizedPnl', 'notionalUsdt', 'leverage', 'tradeTime']);
  for (const position of body.positions) {
    if (!position || typeof position !== 'object' || Array.isArray(position)) return 'invalid position';
    if (Object.keys(position).some(key => !allowedPositionFields.has(key))) return 'invalid position fields';
    if (position.symbol !== undefined && (typeof position.symbol !== 'string' || position.symbol.length > 30)) return 'invalid position symbol';
    if (position.side !== undefined && !SIDES.includes(position.side)) return 'invalid position side';
    if (position.action !== undefined && !ACTIONS.includes(position.action)) return 'invalid position action';
    for (const key of ['quantity', 'entryPrice', 'markPrice', 'unrealizedPnl', 'notionalUsdt', 'leverage']) if (position[key] !== undefined && (typeof position[key] !== 'number' || !Number.isFinite(position[key]))) return 'invalid position number';
    for (const key of ['position_id', 'positionId', 'tradeTime']) if (position[key] !== undefined && position[key] !== null && typeof position[key] !== 'string') return 'invalid position field';
    if (position.tradeTime !== undefined && !iso(position.tradeTime)) return 'invalid position tradeTime';
  }
  return null;
}
export const MAX_BODY_BYTES = MAX;
