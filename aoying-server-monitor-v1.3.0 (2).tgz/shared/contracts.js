export const EVENT_FIELDS = Object.freeze(['symbol', 'side', 'action', 'price', 'quantity', 'notionalUsdt', 'tradeTime', 'rawTextHash']);
export const SIDES = Object.freeze(['long', 'short', 'unknown']);
export const ACTIONS = Object.freeze(['open', 'increase', 'reduce', 'close', 'unknown']);
