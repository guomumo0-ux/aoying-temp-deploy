import { ACTIONS, SIDES } from './contracts.js';
export function parseDecimal(text) {
  if (typeof text !== 'string' || !text.trim()) return null;
  const match = text.replaceAll(',', '').match(/[-+]?\d+(?:\.\d+)?/);
  if (!match) return null;
  const value = Number(match[0]);
  return Number.isFinite(value) ? value : null;
}
export function normalizeSide(text) {
  const value = String(text ?? '').toLowerCase();
  if (value.includes('做多') || value.includes('多') || value.includes('long')) return 'long';
  if (value.includes('做空') || value.includes('空') || value.includes('short')) return 'short';
  return SIDES.includes(value) ? value : 'unknown';
}
export function normalizeAction(text) {
  const value = String(text ?? '').toLowerCase();
  if (value.includes('开启') || value.includes('开仓') || value.includes('open')) return 'open';
  if (value.includes('加仓') || value.includes('increase')) return 'increase';
  if (value.includes('减仓') || value.includes('reduce')) return 'reduce';
  if (value.includes('平仓') || value.includes('关闭') || value.includes('close')) return 'close';
  return ACTIONS.includes(value) ? value : 'unknown';
}
