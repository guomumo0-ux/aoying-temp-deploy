import test from 'node:test';
import assert from 'node:assert/strict';
import { enqueue, flushQueue, scheduleNext, registerRuntime } from '../extension/background.js';

const config = { apiUrl: 'https://api.example.test', token: 'secret' };
const payload = { heartbeat: { observedAt: new Date().toISOString() }, events: [], positions: [] };
test('401 stops retries and exposes reconfiguration error', async () => {
  const store = { queue: [{ id: 'a', payload: {} }] };
  const out = await flushQueue(config, async () => new Response('', { status: 401 }), { store, now: () => 0 });
  assert.equal(out.state, 'auth_error');
  assert.equal(store.queue.length, 1);
});
test('successful items are removed and network failures back off', async () => {
  const store = { queue: [] };
  enqueue(payload, store, () => 1000);
  let calls = 0;
  const out = await flushQueue(config, async () => { calls++; return new Response('', { status: 200 }); }, { store, now: () => 1000 });
  assert.equal(calls, 1); assert.equal(out.state, 'ok'); assert.equal(store.queue.length, 0);
});
test('enqueue persists unconfigured payload and scheduler picks earliest retry', async () => {
  const store = { queue: [] }; let saves = 0; const payload = { heartbeat: { observedAt: new Date().toISOString() }, events: [], positions: [] };
  enqueue(payload, store, () => 1000, { persist: () => { saves++; } });
  assert.equal(saves, 1); store.queue.push({ id: 'later', nextAt: 9000 });
  let scheduled; assert.equal(scheduleNext(store, when => { scheduled = when; }, () => 0), 1000); assert.equal(scheduled, 1000);
});
test('retry sequence persists exact 5/15/30/60 second delays', async () => {
  const store = { queue: [{ id: 'a', payload, attempts: 0, nextAt: 0 }] }; const saves = []; let now = 0;
  for (const delay of [5000, 15000, 30000, 60000]) { const out = await flushQueue(config, async () => { throw new Error('offline'); }, { store, now: () => now, persist: s => saves.push({ attempts: s.queue[0].attempts, nextAt: s.queue[0].nextAt }) }); assert.equal(out.state, 'retrying'); assert.equal(store.queue[0].nextAt, now + delay); now = store.queue[0].nextAt; }
  assert.deepEqual(saves.map(x => x.nextAt), [5000, 20000, 50000, 110000]);
});
test('runtime wiring handles heartbeat, startup, alarm, and auth persistence', async () => {
  const listeners = {}; const saved = { queue: [], apiUrl: 'https://api.example.test', token: 'secret' }; let sets = 0; const alarms = [];
  const api = { storage: { local: { async get() { return saved; }, async set(v) { Object.assign(saved, v); sets++; } } }, runtime: { onMessage: { addListener(fn) { listeners.message = fn; } }, onStartup: { addListener(fn) { listeners.startup = fn; } } }, alarms: { create(name, info) { alarms.push({ name, ...info }); }, onAlarm: { addListener(fn) { listeners.alarm = fn; } } } };
  registerRuntime(api, { fetchFn: async () => new Response('', { status: 401 }) });
  let reply; listeners.message({ type: 'test-heartbeat' }, {}, value => { reply = value; }); await new Promise(r => setImmediate(r)); assert.equal(reply.ok, true); assert.equal(saved.queue[0].payload.heartbeat.sourceId, 'manual-test'); assert.ok(sets > 0);
  listeners.startup(); await new Promise(r => setImmediate(r)); listeners.alarm({ name: 'queue-flush' }); await new Promise(r => setImmediate(r)); assert.ok(saved.error === 'auth_error'); assert.ok(alarms.every(alarm => alarm.name === 'queue-flush' && Number.isFinite(alarm.when) && alarm.when > 0));
});
