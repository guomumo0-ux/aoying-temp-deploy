import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { scryptSync } from 'node:crypto';
import { request } from 'node:http';
import { buildApp, listRecentEvents } from '../server/src/app.js';
import { createDb } from '../server/src/db.js';

test('ingest to SQLite to authenticated dashboard preserves event and health', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'aoying-e2e-'));
  const dbPath = join(dir, 'monitor.sqlite');
  const db = createDb(dbPath);
  const salt = 'e2e-salt';
  const passwordHash = `${salt}:${scryptSync('e2e-password', salt, 32).toString('hex')}`;
  const app = buildApp({ ingestToken: 'e2e-token', adminPasswordHash: passwordHash, sessionSecret: 'e2e-session' }, db);
  const observedAt = new Date().toISOString();
  const payload = { heartbeat: { sourceId: 'e2e', observedAt, parserVersion: '1', status: 'ok' }, events: [{ event_id: 'e2e-event-1', symbol: 'HYPEUSDT', side: 'long', action: 'open', price: 71.3, quantity: 10, notionalUsdt: 713, tradeTime: observedAt, rawTextHash: 'e2e-hash' }], positions: [] };
  let server;
  try {
    server = await app.listen(0, '127.0.0.1');
    const port = server.address().port;
    const post = body => new Promise((resolve, reject) => { const req = request({ hostname: '127.0.0.1', port, path: '/api/v1/ingest', method: 'POST', headers: { authorization: 'Bearer e2e-token', 'content-type': 'application/json' } }, res => { let text = ''; res.on('data', chunk => text += chunk); res.on('end', () => resolve({ status: res.statusCode, json: JSON.parse(text) })); }); req.on('error', reject); req.end(JSON.stringify(body)); });
    assert.equal((await post(payload)).status, 200);
    assert.equal((await post(payload)).status, 200);
    const base = `http://127.0.0.1:${port}`;
    const login = await fetch(`${base}/login`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ password: 'e2e-password' }) });
    assert.equal(login.status, 200);
    const cookie = login.headers.get('set-cookie').split(';', 1)[0];
    const dashboard = await fetch(`${base}/api/v1/dashboard`, { headers: { cookie } });
    assert.equal(dashboard.status, 200);
    const data = await dashboard.json();
    assert.equal(data.health.collector, 'healthy');
    assert.equal(data.health.snapshot, 'fresh');
    const events = await fetch(`${base}/api/v1/events`, { headers: { cookie } });
    const eventData = await events.json();
    assert.equal(events.status, 200);
    assert.equal(eventData.events[0].symbol, 'HYPEUSDT');
    assert.equal(eventData.events[0].side, 'long');
    assert.equal(db.prepare('select count(*) n from events').get().n, 1);
  } finally { if (server) await new Promise(resolve => server.close(resolve)); db.close(); await rm(dir, { recursive: true, force: true }); }
});

test('recent event query returns only the last 48 hours', () => {
  const db = createDb(':memory:');
  const now = Date.parse('2026-08-20T12:00:00Z');
  const insert = db.prepare('INSERT INTO events(event_id,trade_time,observed_at) VALUES(?,?,?)');
  insert.run('inside', '2026-08-18T13:00:00Z', '2026-08-20T12:00:00Z');
  insert.run('outside', '2026-08-18T11:00:00Z', '2026-08-20T12:00:00Z');
  assert.deepEqual(listRecentEvents(db, now).map(event => event.event_id), ['inside']);
  db.close();
});
