import test from 'node:test';
import assert from 'node:assert/strict';
import { parseDecimal, normalizeSide, normalizeAction } from '../shared/normalize.js';

test('normalizes Chinese long open trade fields', () => {
  assert.equal(parseDecimal('136,388.40601379USDT'), 136388.40601379);
  assert.equal(normalizeSide('开启做多'), 'long');
  assert.equal(normalizeAction('开启做多'), 'open');
});

test('missing numeric text stays null', () => {
  assert.equal(parseDecimal('未显示'), null);
});
