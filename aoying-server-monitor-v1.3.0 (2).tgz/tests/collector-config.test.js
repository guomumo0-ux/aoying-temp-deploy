import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { readFileSync } from 'node:fs';
import test from 'node:test';

import { loadCollectorConfig } from '../collector/config.js';
import { runCollector } from '../collector/main.js';

const token = 'a'.repeat(64);

test('uses loopback defaults', () => {
  const config = loadCollectorConfig({ INGEST_TOKEN: token });

  assert.equal(config.apiUrl, 'http://127.0.0.1:8788');
  assert.equal(config.proxyUrl, 'socks5://127.0.0.1:1080');
  assert.equal(config.pollMs, 10_000);
});

test('rejects public proxy listeners', () => {
  assert.throws(
    () => loadCollectorConfig({ INGEST_TOKEN: token, COLLECTOR_PROXY_URL: 'socks5://0.0.0.0:1080' }),
    /COLLECTOR_PROXY_URL/
  );
});

test('rejects public API listeners and malformed ingest tokens', () => {
  assert.throws(
    () => loadCollectorConfig({ INGEST_TOKEN: token, COLLECTOR_API_URL: 'http://monitor.example:8788' }),
    /COLLECTOR_API_URL/
  );
  assert.throws(() => loadCollectorConfig({ INGEST_TOKEN: 'a'.repeat(63) }), /INGEST_TOKEN/);
  assert.throws(() => loadCollectorConfig({ INGEST_TOKEN: 'g'.repeat(64) }), /INGEST_TOKEN/);
});

test('collector orders after sing-box without stopping when sing-box is stopped', () => {
  const unit = readFileSync('deploy/aoying-collector.service', 'utf8');

  assert.match(unit, /^Wants=.*sing-box\.service/m);
  assert.match(unit, /^After=.*sing-box\.service/m);
  assert.doesNotMatch(unit, /^Requires=.*sing-box\.service/m);
});

test('stops the polling loop and closes Chromium on SIGTERM', async () => {
  const processLike = new EventEmitter();
  let resolveStarted;
  const started = new Promise(resolve => { resolveStarted = resolve; });
  let receivedSignal;
  let closed = false;

  const running = runCollector({
    env: { INGEST_TOKEN: token },
    processLike,
    dependencies: {
      chromium: {},
      createBrowser: async () => {
        resolveStarted();
        return { close: async () => { closed = true; } };
      },
      createIngestClient: () => ({}),
      createLoop: ({ browser, ingest, intervals }) => {
        assert.deepEqual(intervals, [10_000, 30_000, 60_000, 300_000]);
        assert.equal(typeof browser.close, 'function');
        assert.deepEqual(ingest, {});
        return {
          run: signal => new Promise(resolve => {
            receivedSignal = signal;
            signal.addEventListener('abort', resolve, { once: true });
          }),
        };
      },
    },
  });

  await started;
  processLike.emit('SIGTERM');
  await running;

  assert.equal(receivedSignal.aborted, true);
  assert.equal(closed, true);
  assert.equal(processLike.listenerCount('SIGTERM'), 0);
  assert.equal(processLike.listenerCount('SIGINT'), 0);
});

test('SIGINT closes an in-flight browser before the loop settles', async () => {
  const processLike = new EventEmitter();
  let resolveStarted;
  const started = new Promise(resolve => { resolveStarted = resolve; });
  let resolveInFlight;
  const inFlight = new Promise(resolve => { resolveInFlight = resolve; });
  let abortObserved = false;
  let closeCalls = 0;

  const running = runCollector({
    env: { INGEST_TOKEN: token },
    processLike,
    dependencies: {
      chromium: {},
      createBrowser: async () => {
        resolveStarted();
        return {
          close: async () => {
            closeCalls += 1;
            resolveInFlight();
          },
        };
      },
      createIngestClient: () => ({}),
      createLoop: () => ({
        run: signal => {
          signal.addEventListener('abort', () => { abortObserved = true; }, { once: true });
          return inFlight;
        },
      }),
    },
  });

  await started;
  processLike.emit('SIGINT');
  await new Promise(resolve => setImmediate(resolve));
  const closeCallsBeforeLoopSettles = closeCalls;
  resolveInFlight();
  await running;

  assert.equal(abortObserved, true);
  assert.equal(closeCallsBeforeLoopSettles, 1);
  assert.equal(closeCalls, 1);
});

test('SIGTERM aborts a stalled ingest and lets the collector runtime settle', async () => {
  const processLike = new EventEmitter();
  let resolveIngestStarted;
  const ingestStarted = new Promise(resolve => { resolveIngestStarted = resolve; });
  let resolveFallback;
  let receivedSignal;

  const running = runCollector({
    env: { INGEST_TOKEN: token },
    processLike,
    dependencies: {
      chromium: {},
      createBrowser: async () => ({
        read: async () => ({ pageState: { state: 'blocked' }, payload: null }),
        close: async () => {},
      }),
      createIngestClient: () => ({
        send: async (_payload, { signal } = {}) => {
          receivedSignal = signal;
          resolveIngestStarted();
          await new Promise(resolve => {
            resolveFallback = resolve;
            signal?.addEventListener('abort', resolve, { once: true });
          });
        },
      }),
    },
  });

  await ingestStarted;
  processLike.emit('SIGTERM');
  const outcome = await Promise.race([
    running.then(() => 'settled'),
    new Promise(resolve => setImmediate(() => resolve('pending'))),
  ]);
  if (outcome === 'pending') resolveFallback();
  await running;

  assert.equal(outcome, 'settled');
  assert.equal(receivedSignal?.aborted, true);
});
