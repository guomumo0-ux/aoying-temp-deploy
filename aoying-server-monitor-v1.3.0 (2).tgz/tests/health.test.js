import test from 'node:test';
import assert from 'node:assert/strict';
import { computeHealth, buildApp } from '../server/src/app.js';
import { createDb } from '../server/src/db.js';
import { scryptSync } from 'node:crypto';
import { createSession, verifySession } from '../server/src/auth.js';

const now = '2026-08-20T06:10:00Z';

test('marks collection interrupted after 60 seconds', () => {
  assert.equal(computeHealth('2026-08-20T06:08:59Z', '2026-08-20T06:09:30Z', now).collector, 'interrupted');
});

test('marks snapshot stale after 90 seconds', () => {
  assert.equal(computeHealth('2026-08-20T06:09:50Z', '2026-08-20T06:08:29Z', now).snapshot, 'stale');
});

test('invalid timestamps are never seen or missing', () => {
  const health = computeHealth('not-a-time', 'also-invalid', now);
  assert.equal(health.collector, 'never_seen');
  assert.equal(health.snapshot, 'missing');
});

test('login creates a signed session and protects dashboard queries', async () => {
  const salt = 'test-salt';
  const hash = `${salt}:${scryptSync('correct horse', salt, 32).toString('hex')}`;
  const app = buildApp({ ingestToken: 'secret', adminPasswordHash: hash, sessionSecret: 'session-secret' }, createDb(':memory:'));
  const denied = await app.inject({ method: 'GET', url: '/api/v1/dashboard' });
  assert.equal(denied.statusCode, 401);
  const login = await app.inject({ method: 'POST', url: '/login', payload: { password: 'correct horse' } });
  assert.equal(login.statusCode, 200);
  assert.match(login.headers['set-cookie'], /HttpOnly/);
  assert.match(login.headers['set-cookie'], /Secure/);
  assert.match(login.headers['set-cookie'], /SameSite=Strict/);
  const ok = await app.inject({ method: 'GET', url: '/api/v1/dashboard', headers: { cookie: login.headers['set-cookie'] } });
  assert.equal(ok.statusCode, 200);
  assert.equal((await app.inject({ method: 'POST', url: '/login', payload: { password: 'wrong' } })).statusCode, 401);
  assert.equal((await app.inject({ method: 'POST', url: '/logout', headers: { cookie: login.headers['set-cookie'] } })).headers['set-cookie'].includes('Max-Age=0'), true);
  assert.equal((await app.inject({ method: 'GET', url: '/api/v1/dashboard', headers: { cookie: login.headers['set-cookie'] } })).statusCode, 401);
  assert.equal((await app.inject({ method: 'GET', url: '/api/v1/events', headers: { cookie: login.headers['set-cookie'] } })).statusCode, 401);
  assert.equal(verifySession(createSession('session-secret', Date.parse(now) - 13 * 60 * 60 * 1000), 'session-secret', Date.parse(now)), false);
});

test('serves assets independent of current working directory', async () => {
  const previous = process.cwd(); process.chdir('/tmp');
  try {
    const app = buildApp({ ingestToken: 'secret', adminPasswordHash: 'x', sessionSecret: 'session-secret' }, createDb(':memory:'));
    const page = await app.inject({ method: 'GET', url: '/index.html' });
    assert.equal(page.statusCode, 200);
    assert.match(page.body, /熬鹰资本交易监控演示/);
  } finally { process.chdir(previous); }
});

test('dashboard and events return stored read-only data', async () => {
  const salt = 'test-salt';
  const hash = `${salt}:${scryptSync('correct horse', salt, 32).toString('hex')}`;
  const db = createDb(':memory:');
  const observedAt = new Date().toISOString();
  db.prepare('INSERT INTO heartbeats VALUES (?,?)').run(observedAt, '1');
  db.prepare('INSERT INTO snapshots VALUES (?,?)').run(observedAt, '1');
  db.prepare('INSERT INTO events VALUES (?,?,?,?,?,?,?,?,?,?)').run('e1','HYPEUSDT','long','open',71.3,2,142,observedAt,'h',observedAt);
  const app = buildApp({ ingestToken: 'secret', adminPasswordHash: hash, sessionSecret: 'session-secret' }, db);
  const cookie = (await app.inject({ method: 'POST', url: '/login', payload: { password: 'correct horse' } })).headers['set-cookie'];
  const dashboard = await app.inject({ method: 'GET', url: '/api/v1/dashboard', headers: { cookie } });
  const events = await app.inject({ method: 'GET', url: '/api/v1/events', headers: { cookie } });
  assert.equal(dashboard.json().lastSnapshot, observedAt);
  assert.equal(events.json().events[0].symbol, 'HYPEUSDT');
});
