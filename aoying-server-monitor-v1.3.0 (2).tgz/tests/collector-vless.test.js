import test from 'node:test';
import assert from 'node:assert/strict';
import { parseVlessReality, toSingBoxConfig } from '../collector/vless.js';

const valid = 'vless://00000000-0000-4000-8000-000000000001@proxy.example:443?encryption=none&security=reality&sni=www.example.com&fp=chrome&pbk=PUBLIC_KEY&sid=01&type=tcp';

test('parses Reality fields', () => {
  assert.deepEqual(parseVlessReality(valid), {
    uuid: '00000000-0000-4000-8000-000000000001',
    server: 'proxy.example',
    serverPort: 443,
    serverName: 'www.example.com',
    fingerprint: 'chrome',
    publicKey: 'PUBLIC_KEY',
    shortId: '01'
  });
});

test('rejects unsupported links', () => {
  for (const uri of [
    valid.replace('security=reality', 'security=tls'),
    valid.replace('&pbk=PUBLIC_KEY', ''),
    valid.replace('type=tcp', 'type=ws')
  ]) {
    assert.throws(() => parseVlessReality(uri));
  }
});

test('binds SOCKS to loopback', () => {
  assert.deepEqual(toSingBoxConfig(parseVlessReality(valid)).inbounds[0], {
    type: 'socks',
    tag: 'aoying-socks',
    listen: '127.0.0.1',
    listen_port: 1080
  });
});
