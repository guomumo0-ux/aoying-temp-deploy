import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { join, dirname, resolve, posix } from 'node:path';
const root = resolve(dirname(new URL(import.meta.url).pathname), '..');

test('extension package preserves JS import targets', () => {
  execFileSync(process.execPath, ['scripts/package-extension.mjs'], { cwd: root, stdio: 'ignore' });
  const zip = join(root, 'dist/aoying-monitor-extension.zip');
  const names = execFileSync('unzip', ['-Z1', zip], { encoding: 'utf8' }).trim().split('\n');
  const files = new Set(names.filter(name => name.endsWith('.js')));
  for (const name of files) {
    const source = execFileSync('unzip', ['-p', zip, name], { encoding: 'utf8' });
    for (const specifier of source.matchAll(/from\s+['"](\.\.?\/[^'"]+)['"]/g)) {
      const packageTarget = posix.normalize(posix.join(posix.dirname(name), specifier[1]));
      assert.ok(names.includes(packageTarget), `${name} imports missing ${packageTarget}`);
    }
  }
  assert.ok(names.includes('manifest.json'), 'installable package needs manifest.json at its root');
  assert.ok(names.includes('extension/content/backfill.js'), 'package includes the 48-hour history loader');
  assert.ok(!names.some(name => /(^|\/)(tests|\.env|node_modules|.*\.sqlite)/.test(name)));
});
