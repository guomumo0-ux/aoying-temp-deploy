import assert from 'node:assert/strict';
import test from 'node:test';

import { createIngestClient } from '../collector/ingest-client.js';

test('uses existing bearer contract', async () => {
  let request;
  const client = createIngestClient({
    apiUrl: 'http://127.0.0.1:8788',
    token: 'synthetic-test-token',
    fetchFn: async (url, init) => {
      request = { url, init };
      return { ok: true, status: 200 };
    },
  });

  await client.send({ heartbeat: {}, events: [], positions: [] });

  assert.equal(request.url, 'http://127.0.0.1:8788/api/v1/ingest');
  assert.equal(request.init.method, 'POST');
  assert.equal(request.init.headers.authorization, 'Bearer synthetic-test-token');
  assert.equal(request.init.headers['content-type'], 'application/json');
  assert.deepEqual(JSON.parse(request.init.body), { heartbeat: {}, events: [], positions: [] });
});

test('activates Telegram through the authenticated collector endpoint', async () => {
  let request;
  const client = createIngestClient({
    apiUrl: 'http://127.0.0.1:8788',
    token: 'synthetic-test-token',
    fetchFn: async (url, init) => {
      request = { url, init };
      return { ok: true, status: 200 };
    },
  });

  await client.activate();

  assert.equal(request.url, 'http://127.0.0.1:8788/api/v1/ingest/activate');
  assert.equal(request.init.method, 'POST');
  assert.equal(request.init.headers.authorization, 'Bearer synthetic-test-token');
  assert.equal(request.init.body, undefined);
});

test('redacts credentials and request details from HTTP errors', async () => {
  const token = 'synthetic-never-print-token';
  const payload = { secret: 'private-payload-value' };
  const client = createIngestClient({
    apiUrl: 'http://127.0.0.1:8788',
    token,
    fetchFn: async () => ({ ok: false, status: 401, headers: { authorization: token } }),
  });

  await assert.rejects(client.send(payload), (error) => {
    const rendered = `${error.name} ${error.message} ${error.stack}`;
    return error.message === 'ingest_http_401'
      && !rendered.includes(token)
      && !rendered.includes('private-payload-value')
      && !rendered.includes('authorization');
  });
});

test('translates fetch failures to the generic network error', async () => {
  const client = createIngestClient({
    apiUrl: 'http://127.0.0.1:8788',
    token: 'synthetic-test-token',
    fetchFn: async () => {
      throw new Error('socket details include synthetic-test-token and private payload');
    },
  });

  await assert.rejects(client.send({ private: 'payload' }), (error) => {
    const rendered = `${error.name} ${error.message} ${error.stack}`;
    return error.message === 'ingest_network_error'
      && !rendered.includes('synthetic-test-token')
      && !rendered.includes('socket details')
      && !rendered.includes('private payload');
  });
});

test('forwards an abort signal and redacts the canceled fetch error', async () => {
  const controller = new AbortController();
  let receivedSignal;
  const client = createIngestClient({
    apiUrl: 'http://127.0.0.1:8788',
    token: 'synthetic-never-print-token',
    fetchFn: async (_url, init) => {
      receivedSignal = init.signal;
      await new Promise((_, reject) => {
        init.signal.addEventListener('abort', () => reject(new Error('abort leaked synthetic-never-print-token')), { once: true });
      });
    },
  });

  const sending = client.send({ private: 'payload' }, { signal: controller.signal });
  controller.abort();

  await assert.rejects(sending, error => {
    const rendered = `${error.name} ${error.message} ${error.stack}`;
    return error.message === 'ingest_network_error' && !rendered.includes('synthetic-never-print-token');
  });
  assert.equal(receivedSignal, controller.signal);
});

test('does not expose response bodies on HTTP errors', async () => {
  const client = createIngestClient({
    apiUrl: 'http://127.0.0.1:8788/',
    token: 'synthetic-test-token',
    fetchFn: async () => ({
      ok: false,
      status: 500,
      text: async () => 'response contains synthetic-test-token and private payload',
    }),
  });

  await assert.rejects(client.send({ private: 'payload' }), (error) => {
    const rendered = `${error.name} ${error.message} ${error.stack}`;
    return error.message === 'ingest_http_500'
      && !rendered.includes('synthetic-test-token')
      && !rendered.includes('private payload');
  });
});

test('redacts errors from response accessors', async () => {
  const client = createIngestClient({
    apiUrl: 'http://127.0.0.1:8788',
    token: 'synthetic-test-token',
    fetchFn: async () => ({
      get ok() {
        throw new Error('ok accessor leaked synthetic-test-token');
      },
    }),
  });

  await assert.rejects(client.send({ private: 'payload' }), (error) => {
    const rendered = `${error.name} ${error.message} ${error.stack}`;
    return error.message === 'ingest_network_error'
      && !rendered.includes('ok accessor leaked')
      && !rendered.includes('synthetic-test-token');
  });
});

test('rejects non-numeric response statuses without exposing them', async () => {
  const client = createIngestClient({
    apiUrl: 'http://127.0.0.1:8788',
    token: 'synthetic-test-token',
    fetchFn: async () => ({ ok: false, status: 'private-status-value' }),
  });

  await assert.rejects(client.send({ private: 'payload' }), (error) => {
    const rendered = `${error.name} ${error.message} ${error.stack}`;
    return error.message === 'ingest_network_error'
      && !rendered.includes('private-status-value');
  });
});
