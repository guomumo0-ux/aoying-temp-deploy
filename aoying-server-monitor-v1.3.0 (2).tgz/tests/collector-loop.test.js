import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';

import { createCollectorLoop } from '../collector/loop.js';
import { buildApp } from '../server/src/app.js';
import { activateTelegram, createDb, writeIngest } from '../server/src/db.js';

const intervals = [10_000, 30_000, 60_000, 300_000];
const observedAt = '2026-08-20T12:00:00.000Z';

function payload(eventId = 'latest') {
  return {
    parserVersion: '2',
    observedAt,
    events: [{
      event_id: eventId,
      symbol: 'HYPEUSDT',
      side: 'long',
      action: 'open',
      price: 70,
      quantity: 2,
      notionalUsdt: 140,
      tradeTime: observedAt,
      rawTextHash: `${eventId}-hash`,
    }],
    positions: [],
  };
}

function payloadAt(eventId, tradeTime) {
  return {
    ...payload(eventId),
    events: [{ ...payload(eventId).events[0], tradeTime }],
  };
}

function abortAfter(cycles) {
  const controller = new AbortController();
  let completedCycles = 0;
  return {
    signal: controller.signal,
    afterCycle() {
      completedCycles += 1;
    },
    abortBeforeSleep() {
      if (completedCycles >= cycles) controller.abort();
    },
  };
}

function tempMarker() {
  return mkdtemp(join(tmpdir(), 'aoying-loop-')).then(dir => ({
    path: join(dir, 'backfill-complete'),
    cleanup: () => rm(dir, { recursive: true, force: true }),
  }));
}

test('polls at 10 seconds without overlapping browser reads', async () => {
  const marker = await tempMarker();
  const sleeps = [];
  const stop = abortAfter(2);
  let active = 0;
  let maxConcurrent = 0;
  const ingested = [];
  const browser = {
    async read() {
      active += 1;
      maxConcurrent = Math.max(maxConcurrent, active);
      await Promise.resolve();
      active -= 1;
      stop.afterCycle();
      return { pageState: { state: 'valid' }, payload: payload() };
    },
    async backfill() {
      return { state: 'cutoff_reached', pages: 0 };
    },
  };

  try {
    await createCollectorLoop({
      browser,
      ingest: { send: async item => ingested.push(item), activate: async () => {} },
      clock: () => observedAt,
      sleep: async ms => {
        stop.abortBeforeSleep();
        if (!stop.signal.aborted) sleeps.push(ms);
      },
      intervals,
      markerPath: marker.path,
    }).run(stop.signal);

    assert.deepEqual(sleeps, [10_000]);
    assert.equal(maxConcurrent, 1);
    assert.equal(ingested.length, 2);
  } finally {
    await marker.cleanup();
  }
});

test('backs off after failures and resets to the base delay after a successful read', async () => {
  const marker = await tempMarker();
  const sleeps = [];
  const stop = abortAfter(4);
  const states = ['proxy_error', 'proxy_error', 'valid', 'proxy_error'];
  const browser = {
    async read() {
      const state = states.shift();
      stop.afterCycle();
      return state === 'valid'
        ? { pageState: { state }, payload: payload() }
        : { pageState: { state }, payload: null };
    },
    async backfill() {
      return { state: 'cutoff_reached', pages: 0 };
    },
  };

  try {
    await createCollectorLoop({
      browser,
      ingest: { send: async () => {}, activate: async () => {} },
      clock: () => observedAt,
      sleep: async ms => {
        stop.abortBeforeSleep();
        if (!stop.signal.aborted) sleeps.push(ms);
      },
      intervals,
      markerPath: marker.path,
    }).run(stop.signal);

    assert.deepEqual(sleeps, [10_000, 30_000, 10_000]);
  } finally {
    await marker.cleanup();
  }
});

test('caps consecutive failures at the five-minute retry delay', async () => {
  const marker = await tempMarker();
  const sleeps = [];
  const stop = abortAfter(5);
  const browser = {
    async read() {
      stop.afterCycle();
      return { pageState: { state: 'proxy_error' }, payload: null };
    },
  };

  try {
    await createCollectorLoop({
      browser,
      ingest: { send: async () => {} },
      clock: () => observedAt,
      sleep: async ms => {
        stop.abortBeforeSleep();
        if (!stop.signal.aborted) sleeps.push(ms);
      },
      intervals,
      markerPath: marker.path,
    }).run(stop.signal);

    assert.deepEqual(sleeps, [10_000, 30_000, 60_000, 300_000]);
  } finally {
    await marker.cleanup();
  }
});

test('passes the stop signal to its awaited sleep', async () => {
  const marker = await tempMarker();
  const controller = new AbortController();
  const browser = {
    async read() {
      return { pageState: { state: 'proxy_error' }, payload: null };
    },
  };

  try {
    await createCollectorLoop({
      browser,
      ingest: { send: async () => {} },
      clock: () => observedAt,
      sleep: async (_ms, signal) => {
        assert.equal(signal, controller.signal);
        controller.abort();
      },
      intervals,
      markerPath: marker.path,
    }).run(controller.signal);
  } finally {
    await marker.cleanup();
  }
});

test('passes shutdown to a stalled ingest and exits when the request aborts', async () => {
  const marker = await tempMarker();
  const controller = new AbortController();
  let resolveStarted;
  const started = new Promise(resolve => { resolveStarted = resolve; });
  let resolveFallback;
  let receivedSignal;
  const browser = {
    async read() {
      return { pageState: { state: 'blocked' }, payload: null };
    },
  };
  const ingest = {
    send: async (_payload, { signal } = {}) => {
      receivedSignal = signal;
      resolveStarted();
      await new Promise(resolve => {
        resolveFallback = resolve;
        signal?.addEventListener('abort', resolve, { once: true });
      });
    },
  };

  try {
    const running = createCollectorLoop({
      browser,
      ingest,
      clock: () => observedAt,
      sleep: async () => {},
      intervals,
      markerPath: marker.path,
    }).run(controller.signal);

    await started;
    controller.abort();
    const outcome = await Promise.race([
      running.then(() => 'settled'),
      new Promise(resolve => setImmediate(() => resolve('pending'))),
    ]);
    if (outcome === 'pending') resolveFallback();
    await running;

    assert.equal(outcome, 'settled');
    assert.equal(receivedSignal, controller.signal);
  } finally {
    await marker.cleanup();
  }
});

test('sends a heartbeat without events for blocked pages', async () => {
  const marker = await tempMarker();
  const stop = abortAfter(1);
  const ingested = [];
  const browser = {
    async read() {
      stop.afterCycle();
      return { pageState: { state: 'blocked' }, payload: null };
    },
    async backfill() {
      throw new Error('backfill must not run for a blocked page');
    },
  };

  try {
    await createCollectorLoop({
      browser,
      ingest: { send: async item => ingested.push(item), activate: async () => {} },
      clock: () => observedAt,
      sleep: async () => stop.abortBeforeSleep(),
      intervals,
      markerPath: marker.path,
    }).run(stop.signal);

    assert.deepEqual(ingested.map(item => item.events), [[]]);
    assert.equal(ingested[0].heartbeat.status, 'blocked');
  } finally {
    await marker.cleanup();
  }
});

test('maps parser states to heartbeat-only parse errors', async () => {
  const marker = await tempMarker();
  const stop = abortAfter(1);
  const ingested = [];
  const browser = {
    async read() {
      stop.afterCycle();
      return { pageState: { state: 'empty' }, payload: null };
    },
  };

  try {
    await createCollectorLoop({
      browser,
      ingest: { send: async item => ingested.push(item), activate: async () => {} },
      clock: () => observedAt,
      sleep: async () => stop.abortBeforeSleep(),
      intervals,
      markerPath: marker.path,
    }).run(stop.signal);

    assert.equal(ingested[0].heartbeat.status, 'parse_error');
    assert.deepEqual(ingested[0].events, []);
  } finally {
    await marker.cleanup();
  }
});

test('marks backfill complete only after bounded history is ingested', async () => {
  const marker = await tempMarker();
  const stop = abortAfter(1);
  const ingested = [];
  const browser = {
    async read() {
      stop.afterCycle();
      return { pageState: { state: 'valid' }, payload: payload('current') };
    },
    async backfill({ emit }) {
      await emit(payload('history'));
      return { state: 'cutoff_reached', pages: 1 };
    },
  };

  try {
    await createCollectorLoop({
      browser,
      ingest: { send: async item => ingested.push(item), activate: async () => {} },
      clock: () => observedAt,
      sleep: async () => stop.abortBeforeSleep(),
      intervals,
      markerPath: marker.path,
    }).run(stop.signal);

    assert.deepEqual(ingested.map(item => item.events.map(event => event.event_id)), [['history'], ['current']]);
    assert.equal(await readFile(marker.path, 'utf8'), 'complete\n');
  } finally {
    await marker.cleanup();
  }
});

test('does not activate Telegram or mark backfill complete after shutdown during backfill', async () => {
  const marker = await tempMarker();
  const controller = new AbortController();
  let activations = 0;
  const browser = {
    async read() {
      return { pageState: { state: 'valid' }, payload: payload('current') };
    },
    async backfill() {
      controller.abort();
      return { state: 'cutoff_reached', pages: 0 };
    },
  };

  try {
    await createCollectorLoop({
      browser,
      ingest: { send: async () => {}, activate: async () => { activations += 1; } },
      clock: () => observedAt,
      sleep: async () => {},
      intervals,
      markerPath: marker.path,
    }).run(controller.signal);

    assert.equal(activations, 0);
    await assert.rejects(readFile(marker.path, 'utf8'), { code: 'ENOENT' });
  } finally {
    await marker.cleanup();
  }
});

test('stores initial history before Telegram activation and queues a later discovery once', async () => {
  const marker = await tempMarker();
  const db = createDb(':memory:');
  const controllers = [new AbortController(), new AbortController()];
  const pages = [
    payloadAt('initial-current', '2026-08-20T12:01:00.000Z'),
    payloadAt('later-discovery', '2026-08-20T12:03:00.000Z'),
  ];
  let controllerIndex = 0;
  const browser = {
    async read() {
      return { pageState: { state: 'valid' }, payload: pages.shift() };
    },
    async backfill({ emit }) {
      await emit(payloadAt('initial-history', '2026-08-18T12:03:00.000Z'));
      return { state: 'cutoff_reached', pages: 1 };
    },
  };
  const ingest = {
    send: async item => writeIngest(db, item),
    activate: async () => activateTelegram(db, '2026-08-20T12:02:00.000Z'),
  };
  const loop = createCollectorLoop({
    browser,
    ingest,
    clock: () => '2026-08-20T12:02:00.000Z',
    sleep: async () => controllers[controllerIndex].abort(),
    intervals,
    markerPath: marker.path,
  });

  try {
    await loop.run(controllers[controllerIndex].signal);
    assert.deepEqual(
      db.prepare('SELECT event_id FROM events ORDER BY event_id').all().map(row => row.event_id),
      ['initial-current', 'initial-history']
    );
    assert.deepEqual(db.prepare('SELECT event_id FROM telegram_outbox ORDER BY event_id').all(), []);

    controllerIndex += 1;
    await loop.run(controllers[controllerIndex].signal);
    assert.deepEqual(
      db.prepare('SELECT event_id FROM telegram_outbox ORDER BY event_id').all().map(row => ({ event_id: row.event_id })),
      [{ event_id: 'later-discovery' }]
    );
  } finally {
    db.close();
    await marker.cleanup();
  }
});

test('collector activation endpoint requires the existing bearer credential', async () => {
  const db = createDb(':memory:');
  const app = buildApp({ ingestToken: 'collector-secret' }, db);

  try {
    assert.equal((await app.inject({ method: 'POST', url: '/api/v1/ingest/activate' })).statusCode, 401);
    assert.equal((await app.inject({
      method: 'POST',
      url: '/api/v1/ingest/activate',
      headers: { authorization: 'Bearer collector-secret' },
    })).statusCode, 200);
    assert.ok(db.prepare("SELECT value FROM settings WHERE key='telegram_enabled_at'").get()?.value);
  } finally {
    db.close();
  }
});

test('retries a failed backfill because it leaves no completion marker', async () => {
  const marker = await tempMarker();
  const stop = abortAfter(2);
  let backfills = 0;
  const browser = {
    async read() {
      stop.afterCycle();
      return { pageState: { state: 'valid' }, payload: payload() };
    },
    async backfill() {
      backfills += 1;
      return { state: 'blocked', pages: 0 };
    },
  };

  try {
    await createCollectorLoop({
      browser,
      ingest: { send: async () => {} },
      clock: () => observedAt,
      sleep: async () => stop.abortBeforeSleep(),
      intervals,
      markerPath: marker.path,
    }).run(stop.signal);

    assert.equal(backfills, 2);
    await assert.rejects(readFile(marker.path, 'utf8'), { code: 'ENOENT' });
  } finally {
    await marker.cleanup();
  }
});
