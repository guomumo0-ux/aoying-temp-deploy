import test from 'node:test';
import assert from 'node:assert/strict';
import { loadConfig } from '../server/src/config.js';
import { spawnSync } from 'node:child_process';
import { readFileSync, statSync, mkdtempSync, writeFileSync, chmodSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const strong = { INGEST_TOKEN: 'a'.repeat(64), ADMIN_PASSWORD_HASH: `${'b'.repeat(32)}:${'c'.repeat(64)}`, SESSION_SECRET: 'd'.repeat(64), DB_PATH: '/var/lib/aoying-monitor/monitor.sqlite' };

test('config rejects short secrets', () => {
  assert.throws(() => loadConfig({ ...strong, INGEST_TOKEN: 'short' }), /INGEST_TOKEN/);
});

test('config accepts strong deployment values and fixes localhost binding', () => {
  const config = loadConfig(strong);
  assert.equal(config.host, '127.0.0.1');
  assert.equal(config.port, 8788);
});

test('Telegram configuration is optional but requires token and chat id together', () => {
  assert.equal(loadConfig(strong).telegram, null);
  assert.throws(() => loadConfig({ ...strong, TELEGRAM_BOT_TOKEN: 'bot-token' }), /TELEGRAM_CHAT_ID/);
  const config = loadConfig({ ...strong, TELEGRAM_BOT_TOKEN: 'bot-token', TELEGRAM_CHAT_ID: '123456' });
  assert.deepEqual(config.telegram, { botToken: 'bot-token', chatId: '123456' });
});

test('secret generator emits compatible non-empty fields without echoing password', () => {
  const out = spawnSync(process.execPath, ['scripts/generate-secrets.mjs'], { input: 'test-password\n', encoding: 'utf8' });
  assert.equal(out.status, 0);
  assert.match(out.stdout, /^INGEST_TOKEN=[0-9a-f]{64}$/m);
  assert.match(out.stdout, /^SESSION_SECRET=[0-9a-f]{64}$/m);
  assert.match(out.stdout, /^ADMIN_PASSWORD_HASH=[^:]+:[0-9a-f]{64}$/m);
  assert.doesNotMatch(out.stdout, /test-password/);
  assert.equal(out.stderr, '');
});

test('deployment templates enforce Node 24 localhost-only HTTPS proxying', () => {
  const service = readFileSync('deploy/aoying-monitor.service', 'utf8');
  const caddy = readFileSync('deploy/Caddyfile.example', 'utf8');
  assert.match(service, /127\.0\.0\.1:8788/);
  assert.match(service, /NoNewPrivileges=true/);
  assert.match(service, /ProtectSystem=strict/);
  assert.match(service, /node(\.exe)? .*server\/src\/server\.js/);
  assert.match(service, /ExecStartPre=.*node24/);
  assert.doesNotMatch(service, /AoyingMonitorListen/);
  assert.match(caddy, /<public-ip-with-dashes>\.sslip\.io/);
  assert.match(caddy, /reverse_proxy 127\.0\.0\.1:8788/);
  assert.match(caddy, /Strict-Transport-Security/);
});

test('deployment verifier validates Node 24, env, service, and Caddy without HTTP fallback', () => {
  const verifier = readFileSync('scripts/verify-deployment.mjs', 'utf8');
  assert.match(verifier, /caddy validate/);
  assert.match(verifier, /major.*24|24.*major/);
  assert.match(verifier, /INGEST_TOKEN/);
  assert.match(verifier, /Caddyfile/);
  assert.match(verifier, /https|HTTPS/);
  assert.match(verifier, /loadConfig/);
  assert.match(verifier, /sslip\.io/);
  assert.match(verifier, /127\.0\.0\.1:8788/);
  assert.doesNotMatch(verifier, /http:\/\//);
});

test('Caddy template requires rendering and renderer accepts only valid sslip hosts/IPs', () => {
  const template = readFileSync('deploy/Caddyfile.example', 'utf8');
  assert.match(template, /<public-ip-with-dashes>\.sslip\.io/);
  const dir = mkdtempSync(join(tmpdir(), 'aoying-render-'));
  const rendered = join(dir, 'Caddyfile');
  const ok = spawnSync(process.execPath, ['scripts/render-caddy.mjs', '--host', '203-0-113-10.sslip.io', '--output', rendered], { encoding: 'utf8' });
  assert.equal(ok.status, 0);
  assert.match(readFileSync(rendered, 'utf8'), /^203-0-113-10\.sslip\.io \{/m);
  const badHost = spawnSync(process.execPath, ['scripts/render-caddy.mjs', '--host', 'http://evil.example', '--output', rendered], { encoding: 'utf8' });
  assert.notEqual(badHost.status, 0);
  const badIp = spawnSync(process.execPath, ['scripts/render-caddy.mjs', '--ip', '999.1.1.1', '--output', rendered], { encoding: 'utf8' });
  assert.notEqual(badIp.status, 0);
  for (const invalid of ['999-1-1-1.sslip.io', '1-2-3.sslip.io', '-1-2-3-4.sslip.io', 'a-2-3-4.sslip.io', '01-2-3-4.sslip.io']) {
    assert.notEqual(spawnSync(process.execPath, ['scripts/render-caddy.mjs', '--host', invalid, '--output', rendered]).status, 0);
  }
  for (const valid of ['0-0-0-0.sslip.io', '255-255-255-255.sslip.io']) {
    assert.equal(spawnSync(process.execPath, ['scripts/render-caddy.mjs', '--host', valid, '--output', rendered]).status, 0);
  }
});

test('verifier rejects unrendered placeholder with actionable error', () => {
  const dir = mkdtempSync(join(tmpdir(), 'aoying-verify-'));
  const env = join(dir, 'env'); const caddy = join(dir, 'Caddyfile');
  writeFileSync(env, Object.entries(strong).map(([k,v]) => `${k}=${v}`).join('\n')); chmodSync(env, 0o600);
  writeFileSync(caddy, readFileSync('deploy/Caddyfile.example'));
  const out = spawnSync(process.execPath, ['scripts/verify-deployment.mjs'], { env: {...process.env, AOYING_ENV: env, AOYING_CADDYFILE: caddy}, encoding: 'utf8' });
  assert.notEqual(out.status, 0);
  assert.match(`${out.stdout}${out.stderr}`, /render|placeholder|sslip/i);
});

test('verifier rejects group/other accessible environment file', () => {
  const dir = mkdtempSync(join(tmpdir(), 'aoying-perms-')); const env = join(dir, 'env'); const caddy = join(dir, 'Caddyfile');
  writeFileSync(env, Object.entries(strong).map(([k,v]) => `${k}=${v}`).join('\n')); chmodSync(env, 0o644); writeFileSync(caddy, '203-0-113-10.sslip.io {\n reverse_proxy 127.0.0.1:8788\n}');
  const out = spawnSync(process.execPath, ['scripts/verify-deployment.mjs'], { env: {...process.env, AOYING_ENV: env, AOYING_CADDYFILE: caddy}, encoding: 'utf8' });
  assert.notEqual(out.status, 0); assert.match(`${out.stdout}${out.stderr}`, /accessible|permission/i);
});

test('Node 24 check is executable for systemd', () => {
  assert.equal((statSync('scripts/node24-check.sh').mode & 0o111) !== 0, true);
});
