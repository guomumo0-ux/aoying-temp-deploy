import test from 'node:test';
import assert from 'node:assert/strict';
import { isAllowedPage, collectVisiblePage } from '../extension/content/collector.js';

const url = new URL('https://www.binance.com/zh-CN/square/profile/god_of_trader_tony');
test('collector only accepts the configured trader path', () => {
  assert.equal(isAllowedPage(url), true);
  assert.equal(isAllowedPage(new URL('https://www.binance.com/zh-CN/my/wallet')), false);
});
test('collector reads visible body text into structured payload', () => {
  const out = collectVisiblePage({ location: url, visibilityState: 'visible', body: { innerText: '暂无交易记录' } }, '2026-08-20T06:08:10Z');
  assert.equal(out.heartbeat.observedAt, '2026-08-20T06:08:10Z');
  assert.equal(out.status, 'empty');
  assert.deepEqual(out.positions, []);
});
test('collector continues reading when the trader tab is in the background', () => {
  const out = collectVisiblePage({ location: url, visibilityState: 'hidden', body: { innerText: '暂无交易记录' } }, '2026-08-20T06:08:20Z');
  assert.equal(out.heartbeat.observedAt, '2026-08-20T06:08:20Z');
  assert.equal(out.status, 'empty');
});

test('collector uploads only events inside 48 hours and marks the history boundary', () => {
  const body = [
    '2026-08-18 13:00 开多',
    '以均价为70开启做多HYPEUSDT 永续仓位，成交数量为1HYPE，总价值为70USDT。',
    '2026-08-18 11:00 开多',
    '以均价为69开启做多HYPEUSDT 永续仓位，成交数量为1HYPE，总价值为69USDT。'
  ].join('\n');
  const out = collectVisiblePage({ location: url, visibilityState: 'hidden', body: { innerText: body } }, '2026-08-20T12:00:00Z');
  assert.equal(out.events.length, 1);
  assert.equal(out.events[0].tradeTime, '2026-08-18T13:00:00Z');
  assert.equal(out.historyCutoffReached, true);
});
