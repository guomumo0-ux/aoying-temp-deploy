import test from 'node:test';
import assert from 'node:assert/strict';
import { fingerprintEvent } from '../shared/fingerprint.js';

test('uses a browser-compatible synchronous SHA-256 implementation', async () => {
  const source = await import('../shared/fingerprint.js?browser-check');
  assert.equal(source.fingerprintEvent({}), '246421e1716654d25abc298bb67736dccc8b6d2b376ed2fad50375c436b5ecc3');
  const implementation = await (await import('node:fs')).promises.readFile(new URL('../shared/fingerprint.js', import.meta.url), 'utf8');
  assert.doesNotMatch(implementation, /node:crypto/);
});

test('same semantic event has the same fingerprint', () => {
  const a = {symbol:'HYPEUSDT',side:'long',action:'open',price:71.3,quantity:10,tradeTime:'2026-08-20T06:08:00Z'};
  const b = {...a, observedAt:'2026-08-20T06:08:08Z'};
  assert.equal(fingerprintEvent(a), fingerprintEvent(b));
  assert.match(fingerprintEvent(a), /^[a-f0-9]{64}$/);
});
