import test from 'node:test';
import assert from 'node:assert/strict';
import { createBinanceBrowser } from '../collector/browser.js';

const proxyUrl = 'socks5://127.0.0.1:1080';
const profileUrl = 'https://www.binance.com/zh-CN/square/profile/god_of_trader_tony';
const now = '2026-08-20T06:08:10Z';
const tradeText = [
  '最新交易记录',
  '2026-08-20 06:08 开多',
  '以均价为71.30078开启做多HYPEUSDT 永续仓位，成交数量为1912.86HYPE，总价值为136388.40601379USDT。'
].join('\n');

function fakeChromium({ text = tradeText, tabs = [], gotoError } = {}) {
  const calls = { clicks: [], gotos: [], launches: [], scrolls: 0, waits: [] };
  const page = {
    async goto(url, options) {
      calls.gotos.push({ url, options });
      if (gotoError) throw gotoError;
    },
    locator(selector) {
      if (selector === 'body') return { innerText: async () => text };
      assert.equal(selector, '[role="tab"], button, a');
      return {
        count: async () => tabs.length,
        nth: index => ({
          innerText: async () => tabs[index].text,
          click: async () => calls.clicks.push(tabs[index].text)
        })
      };
    },
    mouse: { wheel: async () => { calls.scrolls += 1; } },
    waitForTimeout: async ms => { calls.waits.push(ms); }
  };
  const browser = {
    newPage: async () => page,
    close: async () => { calls.closed = true; }
  };
  return {
    calls,
    chromium: { launch: async options => { calls.launches.push(options); return browser; } }
  };
}

test('launches headless Chromium through the loopback SOCKS proxy', async () => {
  const fake = fakeChromium();
  const adapter = await createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl });

  assert.deepEqual(fake.calls.launches, [{ headless: true, proxy: { server: proxyUrl } }]);
  await adapter.close();
  assert.equal(fake.calls.closed, true);
});

test('reads only the approved public profile and parses its visible trade text', async () => {
  const fake = fakeChromium();
  const adapter = await createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl });

  const result = await adapter.read(now);

  assert.deepEqual(fake.calls.gotos, [{ url: profileUrl, options: { waitUntil: 'domcontentloaded', timeout: 30_000 } }]);
  assert.equal(result.pageState.state, 'valid');
  assert.equal(result.payload.events.length, 1);
  assert.equal(result.payload.events[0].symbol, 'HYPEUSDT');
  await adapter.close();
});

test('blocked pages never become payloads', async () => {
  const fake = fakeChromium({ text: '403 ERROR The request could not be satisfied' });
  const adapter = await createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl });

  const result = await adapter.read(now);

  assert.equal(result.pageState.state, 'blocked');
  assert.equal(result.payload, null);
  await adapter.close();
});

test('backfill selects the shortest latest-trades control and stops at the 48-hour cutoff', async () => {
  const oldTradeText = tradeText.replace('2026-08-20 06:08', '2026-08-18 06:08');
  const fake = fakeChromium({
    text: oldTradeText,
    tabs: [{ text: '最新交易记录（更多）' }, { text: '最新交易记录' }]
  });
  const emitted = [];
  const adapter = await createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl });

  const result = await adapter.backfill({ emit: payload => emitted.push(payload), maxSteps: 99 });

  assert.deepEqual(fake.calls.clicks, ['最新交易记录']);
  assert.deepEqual(fake.calls.waits, [1500]);
  assert.equal(fake.calls.scrolls, 0);
  assert.equal(result.state, 'cutoff_reached');
  assert.equal(result.pages, 1);
  assert.equal(emitted.length, 1);
  await adapter.close();
});

test('does not emit events when a backfill page becomes a verification wall', async () => {
  const fake = fakeChromium({ text: 'Verify you are human', tabs: [{ text: '最新交易记录' }] });
  const emitted = [];
  const adapter = await createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl });

  const result = await adapter.backfill({ emit: payload => emitted.push(payload), maxSteps: 1 });

  assert.equal(result.state, 'captcha');
  assert.equal(result.pages, 0);
  assert.deepEqual(emitted, []);
  await adapter.close();
});

test('never returns or emits an explicitly empty parser result', async () => {
  const text = ['最新交易记录', '以均价为--', '暂无交易记录'].join('\n');
  const fake = fakeChromium({ text, tabs: [{ text: '最新交易记录' }] });
  const emitted = [];
  const adapter = await createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl });

  const readResult = await adapter.read(now);
  const backfillResult = await adapter.backfill({ emit: payload => emitted.push(payload), maxSteps: 1 });

  assert.equal(readResult.pageState.state, 'empty');
  assert.equal(readResult.payload, null);
  assert.equal(backfillResult.state, 'empty');
  assert.equal(backfillResult.pages, 0);
  assert.deepEqual(emitted, []);
  await adapter.close();
});

test('login and unknown classifier pages never become payloads', async () => {
  for (const [text, state] of [
    ['Log in to view', 'login_wall'],
    ['交易记录暂时不可用', 'unknown']
  ]) {
    const fake = fakeChromium({ text });
    const adapter = await createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl });

    const result = await adapter.read(now);

    assert.equal(result.pageState.state, state);
    assert.equal(result.payload, null);
    await adapter.close();
  }
});

test('caps backfill scrolling at 60 steps even when a larger limit is requested', async () => {
  const current = new Date().toISOString();
  const currentTradeText = tradeText.replace('2026-08-20 06:08', `${current.slice(0, 10)} ${current.slice(11, 16)}`);
  const fake = fakeChromium({ text: currentTradeText, tabs: [{ text: '最新交易记录' }] });
  const emitted = [];
  const adapter = await createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl });

  const result = await adapter.backfill({ emit: payload => emitted.push(payload), maxSteps: 99 });

  assert.equal(result.state, 'step_limit');
  assert.equal(result.pages, 60);
  assert.equal(emitted.length, 60);
  assert.equal(fake.calls.scrolls, 60);
  await adapter.close();
});

test('rejects non-loopback proxies and non-public profile targets with a generic configuration error', async () => {
  const fake = fakeChromium();

  await assert.rejects(
    createBinanceBrowser({ chromium: fake.chromium, proxyUrl: 'socks5://proxy.example:1080', profileUrl }),
    { message: 'browser_config_error' }
  );
  await assert.rejects(
    createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl: 'https://www.binance.com/en/my/orders/exchange/usertrade' }),
    { message: 'browser_config_error' }
  );
  assert.deepEqual(fake.calls.launches, []);
});

test('redacts browser navigation failures behind a generic error code', async () => {
  const fake = fakeChromium({ gotoError: new Error('proxy password=not-for-logs') });
  const adapter = await createBinanceBrowser({ chromium: fake.chromium, proxyUrl, profileUrl });

  await assert.rejects(adapter.read(now), { message: 'browser_navigation_error' });
  await adapter.close();
});
