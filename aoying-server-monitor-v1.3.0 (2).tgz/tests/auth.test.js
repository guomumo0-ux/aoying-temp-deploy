import test from 'node:test';
import assert from 'node:assert/strict';
import { verifyBearer } from '../server/src/auth.js';

test('verifyBearer accepts exact bearer token', () => {
  assert.equal(verifyBearer('Bearer secret', 'secret'), true);
  assert.equal(verifyBearer('Bearer wrong', 'secret'), false);
});

test('verifyBearer rejects malformed or missing headers', () => {
  assert.equal(verifyBearer(undefined, 'secret'), false);
  assert.equal(verifyBearer('Basic secret', 'secret'), false);
});
