import test from 'node:test';
import assert from 'node:assert/strict';
import { createDb, activateTelegram, writeIngest } from '../server/src/db.js';

const loadTelegram = () => import('../server/src/telegram.js').catch(() => null);

function payload(events, observedAt = '2026-08-20T12:02:00Z') {
  return { heartbeat: { sourceId: 'test', observedAt, parserVersion: '2', status: 'ok' }, events, positions: [] };
}

function event(eventId, tradeTime, action = 'open') {
  return { event_id: eventId, symbol: 'HYPEUSDT', side: 'long', action, price: 70, quantity: 2, notionalUsdt: 140, tradeTime, rawTextHash: `${eventId}-hash` };
}

test('Telegram module is available', async () => {
  assert.ok(await loadTelegram());
});

test('activation queues only newly inserted trades after Telegram was enabled', () => {
  const db = createDb(':memory:');
  activateTelegram(db, '2026-08-20T12:00:00Z');
  writeIngest(db, payload([
    event('history', '2026-08-20T11:59:00Z'),
    event('new-trade', '2026-08-20T12:01:00Z')
  ]));
  writeIngest(db, payload([event('new-trade', '2026-08-20T12:01:00Z')]));
  assert.deepEqual(db.prepare('SELECT event_id FROM telegram_outbox ORDER BY event_id').all().map(row => row.event_id), ['new-trade']);
  db.close();
});

test('Telegram worker retries failures and marks successful messages sent', async () => {
  const telegram = await loadTelegram();
  const db = createDb(':memory:');
  activateTelegram(db, '2026-08-20T12:00:00Z');
  writeIngest(db, payload([event('notify-me', '2026-08-20T12:01:00Z', 'close')]));
  const config = { botToken: 'secret-token', chatId: '123456' };
  const failed = await telegram.processTelegramOutbox(db, config, { now: () => Date.parse('2026-08-20T12:02:00Z'), fetchFn: async () => { throw new Error('network'); } });
  assert.equal(failed.failed, 1);
  const retry = db.prepare("SELECT state,attempts,next_attempt_at,last_error FROM telegram_outbox WHERE event_id='notify-me'").get();
  assert.equal(retry.state, 'pending');
  assert.equal(retry.attempts, 1);
  assert.equal(retry.next_attempt_at, '2026-08-20T12:02:05.000Z');
  assert.equal(retry.last_error, 'send_failed');
  const sent = await telegram.processTelegramOutbox(db, config, { now: () => Date.parse('2026-08-20T12:02:05Z'), fetchFn: async (_url, init) => ({ ok: true, json: async () => ({ ok: true }), request: JSON.parse(init.body) }) });
  assert.equal(sent.sent, 1);
  assert.equal(db.prepare("SELECT state FROM telegram_outbox WHERE event_id='notify-me'").get().state, 'sent');
  db.close();
});

test('Telegram message contains Chinese action and trade fields', async () => {
  const telegram = await loadTelegram();
  const message = telegram.formatTelegramMessage(event('format', '2026-08-20T12:01:00Z', 'increase'));
  assert.match(message, /加仓/);
  assert.match(message, /HYPEUSDT/);
  assert.match(message, /70/);
  assert.match(message, /140/);
});
