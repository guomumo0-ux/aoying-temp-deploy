import test from 'node:test';
import assert from 'node:assert/strict';
import { chmodSync, mkdtempSync, mkdirSync, readdirSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';

const setupScript = 'deploy/configure-vless.sh';
const verifierScript = 'scripts/verify-deployment.mjs';
const syntheticUri = 'vless://00000000-0000-4000-8000-000000000007@synthetic.example:443?encryption=none&security=reality&sni=www.synthetic.example&fp=chrome&pbk=SYNTHETIC_KEY&sid=07&type=tcp';
const strong = {
  INGEST_TOKEN: 'a'.repeat(64),
  ADMIN_PASSWORD_HASH: `${'b'.repeat(32)}:${'c'.repeat(64)}`,
  SESSION_SECRET: 'd'.repeat(64),
};

function writeExecutable(path, body) {
  writeFileSync(path, `#!/bin/sh\n${body}`);
  chmodSync(path, 0o755);
}

function makeSetupFakes(dir, { validationFails = false } = {}) {
  const bin = join(dir, 'bin');
  mkdirSync(bin);
  writeExecutable(join(bin, 'install'), `
case "$1" in
  -d) exit 0 ;;
  -m) cp "$3" "$4"; exit $? ;;
esac
exit 1
`);
  writeExecutable(join(bin, 'mktemp'), 'exec /usr/bin/mktemp "$FAKE_TMP_DIR/aoying.XXXXXX"\n');
  writeExecutable(join(bin, 'sing-box'), validationFails ? 'exit 1\n' : '[ "$1" = check ] && [ "$2" = -c ] && [ -s "$3" ]\n');
  writeExecutable(join(bin, 'mv'), 'while [ "$#" -gt 2 ]; do shift; done\nexec /bin/mv "$1" "$FAKE_TMP_DIR/aoying.json"\n');
  return bin;
}

function runSetup(input, env = {}, args = ['-x']) {
  return spawnSync('bash', [...args, setupScript], {
    cwd: process.cwd(),
    input,
    encoding: 'utf8',
    env: { PATH: process.env.PATH, ...env },
  });
}

function makeVerifierFixture({ binanceBody = 'god_of_trader_tony 最新交易记录 以均价为', heartbeat = new Date().toISOString(), disabledUnit, secretLine = '' } = {}) {
  const dir = mkdtempSync(join(tmpdir(), 'aoying-verifier-'));
  const bin = join(dir, 'bin');
  mkdirSync(bin);
  const envPath = join(dir, 'aoying.env');
  const caddyPath = join(dir, 'Caddyfile');
  const configPath = join(dir, 'aoying.json');
  const markerPath = join(dir, 'collector-backfill-complete');
  const dbPath = join(dir, 'monitor.sqlite');
  writeFileSync(envPath, [...Object.entries(strong), ['DB_PATH', dbPath]].map(([key, value]) => `${key}=${value}`).join('\n'));
  chmodSync(envPath, 0o600);
  writeFileSync(caddyPath, '203-0-113-10.sslip.io {\n  reverse_proxy 127.0.0.1:8788\n}\n');
  writeFileSync(configPath, JSON.stringify({ inbounds: [{ tag: 'aoying-socks', listen: '127.0.0.1', listen_port: 1080 }] }));
  chmodSync(configPath, 0o600);
  writeFileSync(markerPath, 'complete\n');
  const db = new DatabaseSync(dbPath);
  db.exec('CREATE TABLE heartbeats(observed_at TEXT NOT NULL); CREATE TABLE events(event_id TEXT NOT NULL);');
  db.prepare('INSERT INTO heartbeats(observed_at) VALUES(?)').run(heartbeat);
  db.close();
  writeExecutable(join(bin, 'systemctl'), `
case "$1" in
  is-active) exit 0 ;;
  is-enabled) [ "${disabledUnit ?? ''}" = "$3" ] && exit 1; exit 0 ;;
  cat)
    case "$2" in
      aoying-monitor) printf '%s\\n' 'NoNewPrivileges=true' 'PrivateTmp=true' 'ProtectSystem=strict' 'ProtectHome=true' 'CapabilityBoundingSet=' 'node24-check' '127.0.0.1:8788' ;;
      aoying-collector) printf '%s\\n' 'NoNewPrivileges=true' 'PrivateTmp=true' 'ProtectSystem=strict' 'ProtectHome=true' 'CapabilityBoundingSet=' 'node24-check' 'After=network-online.target sing-box.service' ;;
      sing-box) printf '%s\\n' 'NoNewPrivileges=true' 'PrivateTmp=true' 'ProtectSystem=strict' 'ProtectHome=true' 'CapabilityBoundingSet=' 'Before=aoying-collector.service' ;;
    esac ;;
  show) printf '%s\\n' 'Environment=INGEST_TOKEN' ;;
esac
`);
  writeExecutable(join(bin, 'ss'), "printf '%s\\n' 'LISTEN 0 4096 127.0.0.1:1080 0.0.0.0:*'\n");
  writeExecutable(join(bin, 'caddy'), 'exit 0\n');
  writeExecutable(join(bin, 'curl'), `case " $* " in *binance.com*) printf '%s' '${binanceBody}' ;; esac\n`);
  writeExecutable(join(bin, 'ps'), 'exit 0\n');
  writeExecutable(join(bin, 'journalctl'), `printf '%s' '${secretLine}'\n`);
  return {
    env: {
      PATH: `${bin}:${process.env.PATH}`,
      AOYING_ENV: envPath,
      AOYING_CADDYFILE: caddyPath,
      AOYING_SING_BOX_CONFIG: configPath,
      AOYING_MARKER_PATH: markerPath,
      AOYING_DATA_DIR: dir,
    },
  };
}

function runVerifier(fixture) {
  return spawnSync(process.execPath, [verifierScript], {
    cwd: process.cwd(),
    encoding: 'utf8',
    env: fixture.env,
  });
}

test('rejects every inherited environment value containing a synthetic VLESS URI without echoing it', () => {
  const out = runSetup('', { SYNTHETIC_URI: syntheticUri }, []);
  assert.equal(out.status, 2);
  assert.doesNotMatch(`${out.stdout}${out.stderr}`, new RegExp(syntheticUri));
  assert.doesNotMatch(`${out.stdout}${out.stderr}`, /SYNTHETIC_URI/);
});

test('disables xtrace before reading a synthetic URI', () => {
  const dir = mkdtempSync(join(tmpdir(), 'aoying-xtrace-'));
  const out = runSetup(`${syntheticUri}\n`, { PATH: `${makeSetupFakes(dir)}:${process.env.PATH}`, FAKE_TMP_DIR: dir });
  assert.equal(out.status, 0);
  assert.match(out.stderr, /^\+ set \+x$/m);
  assert.doesNotMatch(`${out.stdout}${out.stderr}`, new RegExp(syntheticUri));
});

test('leaves only the final synthetic config after success and no staging file after validation failure', () => {
  const successDir = mkdtempSync(join(tmpdir(), 'aoying-clean-success-'));
  const success = runSetup(`${syntheticUri}\n`, { PATH: `${makeSetupFakes(successDir)}:${process.env.PATH}`, FAKE_TMP_DIR: successDir }, []);
  assert.equal(success.status, 0);
  assert.deepEqual(readdirSync(successDir).filter(name => name.startsWith('aoying')), ['aoying.json']);

  const failureDir = mkdtempSync(join(tmpdir(), 'aoying-clean-failure-'));
  const failure = runSetup(`${syntheticUri}\n`, { PATH: `${makeSetupFakes(failureDir, { validationFails: true })}:${process.env.PATH}`, FAKE_TMP_DIR: failureDir }, []);
  assert.equal(failure.status, 1);
  assert.deepEqual(readdirSync(failureDir).filter(name => name.startsWith('aoying')), []);
});

test('live verifier rejects a disabled service even when every service is active', () => {
  const out = runVerifier(makeVerifierFixture({ disabledUnit: 'aoying-collector' }));
  assert.notEqual(out.status, 0);
  assert.match(out.stdout, /^services FAIL$/m);
});

test('live verifier requires Binance profile markers instead of any nonempty proxy body', () => {
  const out = runVerifier(makeVerifierFixture({ binanceBody: 'arbitrary successful response' }));
  assert.notEqual(out.status, 0);
  assert.match(out.stdout, /^local_web_collector FAIL$/m);
});

test('live verifier rejects an invalid heartbeat timestamp', () => {
  const out = runVerifier(makeVerifierFixture({ heartbeat: 'not-a-date' }));
  assert.notEqual(out.status, 0);
  assert.match(out.stdout, /^local_web_collector FAIL$/m);
});

test('secret leakage catches plausible values but not a variable name alone', () => {
  const safe = runVerifier(makeVerifierFixture());
  assert.equal(safe.status, 0);
  assert.match(safe.stdout, /^secret_leakage PASS$/m);
  for (const secretLine of [
    `INGEST_TOKEN=${'1'.repeat(64)}`,
    `TELEGRAM_BOT_TOKEN: "synthetic-bot-token"`,
    `SESSION_SECRET=${'s'.repeat(48)}`,
    `ADMIN_PASSWORD_HASH=${'e'.repeat(32)}:${'f'.repeat(64)}`,
    'Bearer synthetic-bearer-token',
  ]) {
    const leaked = runVerifier(makeVerifierFixture({ secretLine }));
    assert.notEqual(leaked.status, 0);
    assert.match(leaked.stdout, /^secret_leakage FAIL$/m);
  }
});
