import test from 'node:test';
import assert from 'node:assert/strict';

const moduleUrl = new URL('../extension/content/backfill.js', import.meta.url);
const loadModule = () => import(moduleUrl).catch(() => null);

test('48-hour backfill module is available', async () => {
  assert.ok(await loadModule());
});

test('backfill stops after reaching a trade at least 48 hours old', async () => {
  const module = await loadModule();
  assert.equal(module.hasReachedHistoryCutoff([
    { tradeTime: '2026-08-18T11:59:59Z' },
    { tradeTime: '2026-08-20T11:00:00Z' }
  ], Date.parse('2026-08-20T12:00:00Z')), true);
  assert.equal(module.hasReachedHistoryCutoff([
    { tradeTime: '2026-08-18T12:00:01Z' }
  ], Date.parse('2026-08-20T12:00:00Z')), false);
});

test('backfill clicks latest trades and emits each loaded history page', async () => {
  const module = await loadModule();
  let clicked = 0;
  let emitted = 0;
  let scrollTop = 0;
  const tab = { textContent: '最新交易记录', click: () => clicked++ };
  const scroller = { scrollTop, clientHeight: 100, scrollHeight: 400 };
  const document = {
    scrollingElement: scroller,
    querySelectorAll: selector => selector.includes('role') ? [tab] : []
  };
  const pages = [
    { events: [{ tradeTime: '2026-08-20T11:00:00Z' }] },
    { events: [{ tradeTime: '2026-08-18T11:00:00Z' }] }
  ];
  await module.backfillHistory({
    document,
    read: () => pages.shift(),
    emit: () => emitted++,
    wait: async () => {},
    now: () => Date.parse('2026-08-20T12:00:00Z'),
    maxSteps: 5
  });
  assert.equal(clicked, 1);
  assert.equal(emitted, 2);
  assert.ok(scroller.scrollTop > 0);
});
