import test from 'node:test';
import assert from 'node:assert/strict';
import { request } from 'node:http';
import { buildApp } from '../server/src/app.js';
import { createDb } from '../server/src/db.js';

const validPayload = {
  heartbeat: { sourceId: 'test-source', observedAt: new Date().toISOString(), parserVersion: '1', status: 'ok' },
  events: [{ event_id: 'evt-1', symbol: 'HYPEUSDT', side: 'long', action: 'open', price: 71.3, quantity: 10, notionalUsdt: 713, tradeTime: new Date().toISOString(), rawTextHash: 'hash' }],
  positions: []
};

function setup() {
  const db = createDb(':memory:');
  const app = buildApp({ ingestToken: 'secret' }, db);
  return { app, db };
}

test('ingest rejects a missing bearer token', async () => {
  const { app } = setup();
  const res = await app.inject({ method: 'POST', url: '/api/v1/ingest', payload: validPayload });
  assert.equal(res.statusCode, 401);
});

test('ingest stores one event idempotently', async () => {
  const { app, db } = setup();
  const request = { method: 'POST', url: '/api/v1/ingest', headers: { authorization: 'Bearer secret' }, payload: validPayload };
  assert.equal((await app.inject(request)).statusCode, 200);
  assert.equal((await app.inject(request)).statusCode, 200);
  assert.equal(db.prepare('select count(*) n from events').get().n, 1);
});

test('ingest rejects missing heartbeat observedAt', async () => {
  const { app } = setup();
  const payload = { ...validPayload, heartbeat: { sourceId: 'test-source', parserVersion: '1', status: 'ok' } };
  const res = await app.inject({ method: 'POST', url: '/api/v1/ingest', headers: { authorization: 'Bearer secret' }, payload });
  assert.equal(res.statusCode, 400);
});

test('ingest rejects malformed position entries', async () => {
  const { app } = setup();
  const payload = { ...validPayload, positions: [{ symbol: 'HYPEUSDT', side: 'long', unexpected: true }] };
  const res = await app.inject({ method: 'POST', url: '/api/v1/ingest', headers: { authorization: 'Bearer secret' }, payload });
  assert.equal(res.statusCode, 400);
});

test('ingest accepts null tradeTime and stores it safely', async () => {
  const { app, db } = setup();
  const payload = { ...validPayload, events: [{ ...validPayload.events[0], event_id: 'evt-null-time', tradeTime: null }] };
  const res = await app.inject({ method: 'POST', url: '/api/v1/ingest', headers: { authorization: 'Bearer secret' }, payload });
  assert.equal(res.statusCode, 200);
  assert.equal(db.prepare("select trade_time from events where event_id='evt-null-time'").get().trade_time, null);
});

test('ingest accepts events from the last 48 hours but rejects older events', async () => {
  const { app } = setup();
  const now = Date.now();
  const requestFor = (eventId, ageHours) => app.inject({
    method: 'POST', url: '/api/v1/ingest', headers: { authorization: 'Bearer secret' },
    payload: { ...validPayload, events: [{ ...validPayload.events[0], event_id: eventId, tradeTime: new Date(now - ageHours * 3600000).toISOString() }] }
  });
  assert.equal((await requestFor('evt-47-hours', 47)).statusCode, 200);
  assert.equal((await requestFor('evt-49-hours', 49)).statusCode, 400);
});

test('listen serves a real HTTP response', async () => {
  const { app } = setup();
  const server = await app.listen(0, '127.0.0.1');
  const address = server.address();
  const result = await new Promise((resolve, reject) => {
    const req = request({ hostname: '127.0.0.1', port: address.port, path: '/api/v1/ingest', method: 'POST', headers: { authorization: 'Bearer secret', 'content-type': 'application/json' } }, res => {
      let body = ''; res.on('data', chunk => body += chunk); res.on('end', () => resolve({ statusCode: res.statusCode, body }));
    });
    req.on('error', reject); req.end(JSON.stringify(validPayload));
  });
  await new Promise(resolve => server.close(resolve));
  assert.equal(result.statusCode, 200);
  assert.deepEqual(JSON.parse(result.body), { ok: true });
});
