import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseVisibleText } from '../extension/content/parser.js';

const fixture = readFileSync(new URL('./fixtures/latest-trades.txt', import.meta.url), 'utf8');
const positionsFixture = readFileSync(new URL('./fixtures/positions.txt', import.meta.url), 'utf8');
const observedAt = '2026-08-20T06:08:10Z';

test('parses a visible latest-trade line', () => {
  const out = parseVisibleText(fixture, observedAt);
  assert.equal(out.status, 'ok');
  assert.equal(out.parserVersion, '2');
  assert.equal(out.events.length, 1);
  assert.equal(out.events[0].symbol, 'HYPEUSDT');
  assert.equal(out.events[0].side, 'long');
  assert.equal(out.events[0].action, 'open');
  assert.equal(out.events[0].price, 71.30078);
  assert.equal(out.events[0].quantity, 1912.86);
  assert.equal(out.events[0].notionalUsdt, 136388.40601379);
  assert.equal(out.events[0].tradeTime, '2026-08-20T06:08:00Z');
  assert.deepEqual(out.positions, []);
});

test('parses close, increase, and reduce operations from latest trades', () => {
  const text = [
    '2026-08-20 05:00 平多',
    '以均价为70.5关闭做多HYPEUSDT 永续仓位，成交数量为10HYPE，总价值为705USDT。',
    '2026-08-20 04:00 加空',
    '以均价为71.5加仓做空HYPEUSDT 永续仓位，成交数量为5HYPE，总价值为357.5USDT。',
    '2026-08-20 03:00 减空',
    '以均价为69.5减仓做空HYPEUSDT 永续仓位，成交数量为2HYPE，总价值为139USDT。'
  ].join('\n');
  const out = parseVisibleText(text, observedAt);
  assert.deepEqual(out.events.map(event => event.action), ['close', 'increase', 'reduce']);
});

test('does not treat unknown page text as empty positions', () => {
  const out = parseVisibleText('页面加载失败', observedAt);
  assert.equal(out.status, 'parse_error');
  assert.deepEqual(out.events, []);
  assert.deepEqual(out.positions, []);
});

test('does not treat surrounding error text containing an empty phrase as empty', () => {
  const out = parseVisibleText('页面加载失败：暂无持仓，请刷新重试', observedAt);
  assert.equal(out.status, 'parse_error');
});

test('returns empty only for explicit no-position or no-trade wording', () => {
  assert.equal(parseVisibleText('暂无持仓', observedAt).status, 'empty');
  assert.equal(parseVisibleText('暂无交易记录', observedAt).status, 'empty');
});

test('deduplicates repeated visible trade records by event id', () => {
  const out = parseVisibleText(`${fixture}\n${fixture}`, observedAt);
  assert.equal(out.status, 'ok');
  assert.equal(out.events.length, 1);
  assert.match(out.events[0].event_id, /^[a-f0-9]{64}$/);
  assert.equal('eventId' in out.events[0], false);
});

test('keeps missing numeric fields null instead of zero', () => {
  const out = parseVisibleText('2026-08-20 06:08 开多\n以均价为未显示开启做多HYPEUSDT 永续仓位。', observedAt);
  assert.equal(out.status, 'ok');
  assert.equal(out.events[0].price, null);
  assert.equal(out.events[0].quantity, null);
  assert.equal(out.events[0].notionalUsdt, null);
});

test('parses confirmed visible position snapshot with stable identity', () => {
  const out = parseVisibleText(positionsFixture, observedAt);
  assert.equal(out.status, 'ok');
  assert.deepEqual(out.positions, [{ position_id: 'HYPEUSDT:long', symbol: 'HYPEUSDT', side: 'long', quantity: 1912.86, entryPrice: 71.30078 }]);
});

test('unknown position layout is parse_error, never empty', () => {
  assert.equal(parseVisibleText('当前持仓\n数据加载失败', observedAt).status, 'parse_error');
});

test('explicitly empty position snapshot stays empty', () => {
  assert.equal(parseVisibleText('暂无持仓', observedAt).status, 'empty');
});
