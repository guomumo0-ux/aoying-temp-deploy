import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { classifyPage } from '../collector/page-state.js';

const profile = 'https://www.binance.com/en/my/orders/exchange/usertrade';
const fixture = (name) => readFile(new URL(`./fixtures/binance-pages/${name}`, import.meta.url), 'utf8');

test('accepts latest trades', async () => {
  const valid = await fixture('valid.txt');
  assert.equal(classifyPage({ text: valid, url: profile }).state, 'valid');
});

test('rejects block and empty pages', async () => {
  const cloudfront = await fixture('cloudfront.txt');
  assert.equal(classifyPage({ text: cloudfront, url: profile }).state, 'blocked');
  assert.equal(classifyPage({ text: '', url: profile }).state, 'empty');
});

test('rejects login and verification', async () => {
  const login = await fixture('login.txt');
  assert.equal(classifyPage({ text: login, url: profile }).state, 'login_wall');
  assert.equal(classifyPage({ text: 'Verify you are human', url: profile }).state, 'captcha');
});
