#!/usr/bin/env bash
# Configure the reset VLESS Reality credential without putting it in argv, env, or logs.
set +x
set -euo pipefail

contains_inherited_vless_uri() {
  local entry value
  while IFS= read -r -d '' entry; do
    [[ "$entry" == *=* ]] || continue
    value="${entry#*=}"
    case "$value" in
      *[Vv][Ll][Ee][Ss][Ss]://*) return 0 ;;
    esac
  done < <(/usr/bin/env -0)
  return 1
}

if (( $# != 0 )); then
  printf '%s\n' 'This script accepts no arguments.' >&2
  exit 2
fi
if contains_inherited_vless_uri; then
  printf '%s\n' 'Remove VLESS credentials from the environment and use the hidden prompt.' >&2
  exit 2
fi

target_dir='/etc/sing-box'
target_config="$target_dir/aoying.json"
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
repo_dir="$(cd -- "$script_dir/.." && pwd)"
tmp_config=''
stage_config=''

cleanup() {
  if [[ -n "$tmp_config" ]]; then
    rm -f -- "$tmp_config"
  fi
  if [[ -n "$stage_config" ]]; then
    rm -f -- "$stage_config"
  fi
}
trap cleanup EXIT HUP INT TERM

install -d -m 700 "$target_dir"
tmp_config="$(mktemp "$target_dir/.aoying.json.XXXXXX")"

if ! IFS= read -rsp 'Paste reset VLESS Reality URI: ' VLESS_URI; then
  unset VLESS_URI
  printf '\n%s\n' 'No VLESS Reality URI was provided.' >&2
  exit 1
fi
printf '\n' >&2

if ! printf '%s\n' "$VLESS_URI" | node --input-type=module -e '
  import { readFileSync } from "node:fs";
  const { parseVlessReality, toSingBoxConfig } = await import(process.argv[1]);
  const uri = readFileSync(0, "utf8").trim();
  process.stdout.write(`${JSON.stringify(toSingBoxConfig(parseVlessReality(uri)), null, 2)}\n`);
' "$repo_dir/collector/vless.js" > "$tmp_config"; then
  unset VLESS_URI
  printf '%s\n' 'Invalid VLESS Reality URI.' >&2
  exit 1
fi
unset VLESS_URI

if ! sing-box check -c "$tmp_config"; then
  printf '%s\n' 'sing-box validation failed; no configuration was installed.' >&2
  exit 1
fi

stage_config="$(mktemp "$target_dir/.aoying.json.install.XXXXXX")"
if ! install -m 600 "$tmp_config" "$stage_config"; then
  rm -f -- "$stage_config"
  exit 1
fi
mv -f -- "$stage_config" "$target_config"
rm -f -- "$tmp_config"
tmp_config=''
stage_config=''
printf '%s\n' 'VLESS configuration installed.'
