# 熬鹰资本交易监控 V1

这是一个只读监控工具：Chrome MV3 扩展只读取 Binance 指定公开带单页面的可见文字，服务器用独立 Bearer Token 接收快照，并通过登录后的网页展示健康状态、仓位和事件。它不读取 Cookie、localStorage、密码、API Key、余额或订单控件，也不具备下单、跟单或交易写能力。

## Windows 首次安装

1. 在项目目录运行 `node --test`，确认本地测试通过。
2. 运行 `node scripts/package-extension.mjs`，得到 `dist/aoying-monitor-extension.zip`。
3. 解压 ZIP；Chrome 打开 `chrome://extensions`，开启“开发者模式”，点击“加载已解压的扩展程序”，选择解压目录。
4. 打开扩展弹窗，填写 HTTPS API URL 和上传 Token。首次保存时仅请求该 API origin 的权限；拒绝权限不会保存配置。
5. 在 Chrome 中打开 `https://www.binance.com/zh-CN/square/profile/god_of_trader_tony`。扩展会在后台约每 10 秒采集一次，并自动尝试进入“最新交易记录”分段加载近 48 小时公开历史；电脑休眠、Chrome 关闭、页面未登录或币安阻止加载时会中断。“发送测试心跳”用于验证上传链路。

## 服务器部署预检查

服务器需要 Node.js 24（使用内置 `node:sqlite`）和 Caddy；不要把 `.env`、SQLite 文件或 Token 放入 Git。先确认专用端口未被占用、域名 DNS 指向服务器、Caddy 配置目录和现有数据库均已备份。

按以下唯一顺序操作；在第 5 步成功前不要执行任何 `systemctl enable/start` 或 `caddy reload`：

1. 创建专用系统用户和目录（例如 `/opt/aoying-monitor`），复制 `deploy/env.example`，填写秘密；执行 `sudo chown aoying-monitor:aoying-monitor /etc/aoying-monitor/aoying-monitor.env && sudo chmod 600 /etc/aoying-monitor/aoying-monitor.env`。
2. 公网 IPv4 `203.0.113.10` 对应 `203-0-113-10.sslip.io`；运行 `node scripts/render-caddy.mjs --host 203-0-113-10.sslip.io --output /etc/caddy/Caddyfile`，再人工确认 upstream 只监听 localhost。
3. 安装 `sing-box` 后运行 `sudo deploy/configure-vless.sh`。它只在隐藏终端提示符读取**已重置**的 VLESS Reality URI；不要把 URI 放到命令行、环境变量、聊天、Shell 历史或配置模板中。脚本会先验证临时 JSON，随后以 `0600` 原子安装到 `/etc/sing-box/aoying.json`。验证失败时不会启用任何服务。
4. 安装 `deploy/aoying-monitor.service`、`deploy/sing-box.service.d-aoying.conf` 与 `deploy/aoying-collector.service`，设置 `AOYING_ENV=/etc/aoying-monitor/aoying-monitor.env` 和 `AOYING_CADDYFILE=/etc/caddy/Caddyfile`，然后执行 `node scripts/verify-deployment.mjs --static`。失败时停止并修复，不要绕过检查。
5. static verifier 成功后，运行 `systemctl daemon-reload`、`systemctl enable --now sing-box aoying-monitor aoying-collector` 和 `caddy reload`；随后执行 `sudo node scripts/verify-deployment.mjs`。它会确认 SOCKS 仅监听 `127.0.0.1:1080`、三项服务均 active、心跳新鲜、数据去重、日志和进程未泄漏秘密，并以本地 SOCKS5 获取非空、非 CloudFront 的 Binance 页面。live verifier 失败时停止并修复；证书失败时不要降级到 HTTP。

## 日常运维与回滚

- 日志：`journalctl -u aoying-monitor -f`；检查时只搜索状态和错误，不记录 Token 或密码。
- 备份：停止写入后复制 `DB_PATH` 及其 `-wal`/`-shm` 文件，或用 SQLite 在线备份工具；恢复前先停止服务并校验文件权限。
- 停止：`systemctl stop aoying-monitor`；保留备份后再删除新建的 systemd 单元、Caddy 站点和 `/opt/aoying-monitor` 目录。不要删除现有项目、Docker 数据或其他数据库。
- 回滚：停止服务，恢复上一版本源码和 SQLite 备份，重新 `daemon-reload` 并启动；确认 HTTPS 仍有效，再在扩展弹窗检查队列和错误。

## 验收清单

运行 `npm test`、`npm audit --omit=dev` 和 `node scripts/package-extension.mjs`。检查 ZIP 只含扩展 manifest、content/background、popup 和必要 shared 模块，不含测试、`.env`、SQLite、Token 或用户数据。人工验收时确认页面可见后 30 秒内出现数据；关闭目标页超过 60 秒显示采集中断，超过 90 秒显示快照过期。V1 不执行阿里云实际部署。

## 故障排查与安全边界

- 401/auth_error：检查扩展 Token 与 `INGEST_TOKEN` 是否一致，重新保存配置；不要把 Token 写进 URL。
- 队列增长：确认 HTTPS、证书、DNS 和服务日志；网络/5xx 会按 5/15/30/60 秒重试，401/403 会停止并要求重新配置。
- 页面无数据：确认 URL 是指定 trader path、币安已登录且“最新交易记录”公开文本能够加载；扩展不会读取 Cookie、本地账号数据或币安未公开内容。
- 登录失败：检查 `ADMIN_PASSWORD_HASH` 的 `salt:derivedKeyHex` 格式，勿在日志输出密码。所有 dashboard/events 查询都需要 HttpOnly、Secure、SameSite=Strict 会话。
