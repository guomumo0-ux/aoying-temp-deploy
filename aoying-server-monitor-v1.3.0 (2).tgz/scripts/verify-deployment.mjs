import { existsSync, readFileSync, statSync } from 'node:fs';
import { resolve } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { spawnSync } from 'node:child_process';
import { loadConfig } from '../server/src/config.js';
import { isValidSslipHost } from './sslip-host.mjs';

const root = new URL('../', import.meta.url);
const staticMode = process.argv.slice(2).length === 1 && process.argv[2] === '--static';
const liveMode = process.argv.length === 2;
const singBoxConfigPath = process.env.AOYING_SING_BOX_CONFIG ?? '/etc/sing-box/aoying.json';
const markerPath = process.env.AOYING_MARKER_PATH ?? '/var/lib/aoying-monitor/collector-backfill-complete';
const dataDir = resolve(process.env.AOYING_DATA_DIR ?? '/var/lib/aoying-monitor');
const secretPattern = /vless:\/\/|Bearer\s+\S+|\b(?:INGEST_TOKEN|TELEGRAM_BOT_TOKEN|SESSION_SECRET|ADMIN_PASSWORD_HASH)\b\s*(?:=|:)\s*(?:"[^"\r\n]+"|'[^'\r\n]+'|[^\s\r\n]+)/i;
const blockPattern = /403 ERROR|Request blocked|request could not be satisfied|Access Denied/i;
const binanceProfilePattern = /god_of_trader_tony/i;
const binanceTradePattern = /最新交易记录/;
const binancePricePattern = /以均价为/;
const serviceHardening = ['NoNewPrivileges=true', 'PrivateTmp=true', 'ProtectSystem=strict', 'ProtectHome=true', 'CapabilityBoundingSet='];

function file(relative) {
  return readFileSync(new URL(relative, root), 'utf8');
}

function parseEnv(text) {
  const env = {};
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const match = line.match(/^([A-Z_][A-Z0-9_]*)=(.*)$/);
    if (!match) throw new Error('invalid environment line');
    env[match[1]] = match[2];
  }
  return env;
}

function command(commandName, args, options = {}) {
  const result = spawnSync(commandName, args, { encoding: 'utf8', ...options });
  if (result.status !== 0) throw new Error('command failed');
  return result.stdout ?? '';
}

function assertHardenedService(text, { node24 = true } = {}) {
  for (const hardening of serviceHardening) {
    if (!text.includes(hardening)) throw new Error('missing hardening');
  }
  if (node24 && !text.includes('node24-check')) throw new Error('missing Node 24 guard');
}

function serviceText(relative) {
  const text = file(relative);
  assertHardenedService(text);
  return text;
}

function checkNode24() {
  const major = command(process.execPath, ['-p', 'process.versions.node.split(".")[0]']).trim();
  if (major !== '24') throw new Error('wrong Node version');
}

function checkSystemdHardening() {
  const monitor = serviceText('deploy/aoying-monitor.service');
  const collector = serviceText('deploy/aoying-collector.service');
  const singBoxDropIn = file('deploy/sing-box.service.d-aoying.conf');
  assertHardenedService(singBoxDropIn, { node24: false });
  if (!monitor.includes('127.0.0.1:8788') || !collector.includes('After=network-online.target sing-box.service') ||
      !singBoxDropIn.includes('Before=aoying-collector.service')) throw new Error('unit relationship incorrect');
  if (!staticMode) {
    const installedMonitor = command('systemctl', ['cat', 'aoying-monitor']);
    const installedCollector = command('systemctl', ['cat', 'aoying-collector']);
    const installedSingBox = command('systemctl', ['cat', 'sing-box']);
    assertHardenedService(installedMonitor);
    assertHardenedService(installedCollector);
    assertHardenedService(installedSingBox, { node24: false });
    if (!installedMonitor.includes('127.0.0.1:8788') || !installedCollector.includes('After=network-online.target sing-box.service') ||
        !installedSingBox.includes('Before=aoying-collector.service')) throw new Error('installed unit relationship incorrect');
  }
}

function checkSocksLoopback() {
  const rendered = file('collector/vless.js');
  const example = file('deploy/sing-box.json.example');
  if (!rendered.includes("listen: '127.0.0.1'") || !rendered.includes('listen_port: 1080') ||
      !example.includes('"listen": "127.0.0.1"') || !example.includes('"listen_port": 1080')) throw new Error('proxy is not loopback only');
  if (!staticMode) {
    const configStat = statSync(singBoxConfigPath);
    if ((configStat.mode & 0o077) !== 0) throw new Error('sing-box config permissions');
    const config = JSON.parse(readFileSync(singBoxConfigPath, 'utf8'));
    const inbound = config.inbounds?.find(value => value?.tag === 'aoying-socks');
    if (inbound?.listen !== '127.0.0.1' || inbound?.listen_port !== 1080) throw new Error('live proxy bind');
    const listener = command('ss', ['-ltnH']).split(/\r?\n/).filter(line => /:1080(?:\s|$)/.test(line));
    if (listener.length !== 1 || !/\b127\.0\.0\.1:1080\b/.test(listener[0])) throw new Error('live proxy listener');
  }
}

function checkServices() {
  if (staticMode) {
    for (const unit of ['deploy/aoying-monitor.service', 'deploy/aoying-collector.service']) {
      if (!file(unit).includes('WantedBy=multi-user.target')) throw new Error('unit not enabled');
    }
    return;
  }
  for (const unit of ['sing-box', 'aoying-monitor', 'aoying-collector']) {
    command('systemctl', ['is-active', '--quiet', unit]);
    command('systemctl', ['is-enabled', '--quiet', unit]);
  }
}

function checkEnvironment() {
  if (staticMode) {
    const sample = file('deploy/env.example');
    if (!sample.includes('DB_PATH=/var/lib/aoying-monitor/monitor.sqlite')) throw new Error('database path missing');
    return null;
  }
  const envPath = process.env.AOYING_ENV ?? '/etc/aoying-monitor/aoying-monitor.env';
  const envStat = statSync(envPath);
  if ((envStat.mode & 0o077) !== 0) throw new Error('environment file permissions');
  const env = parseEnv(readFileSync(envPath, 'utf8'));
  loadConfig(env);
  return { env, envPath };
}

function checkSslipCaddy() {
  if (staticMode) {
    const template = file('deploy/Caddyfile.example');
    if (!template.includes('<public-ip-with-dashes>.sslip.io') || !/^\s*reverse_proxy\s+127\.0\.0\.1:8788\s*$/m.test(template)) throw new Error('Caddy template');
    return;
  }
  const caddyfile = process.env.AOYING_CADDYFILE ?? new URL('../deploy/Caddyfile.example', import.meta.url).pathname;
  const text = readFileSync(caddyfile, 'utf8');
  if (text.includes('<public-ip-with-dashes>')) throw new Error('unrendered Caddyfile');
  const site = text.split(/\r?\n/).find(line => line.trim() && !line.trim().startsWith('#'))?.trim();
  if (!isValidSslipHost((site ?? '').replace(/\s*\{$/, '')) || !/^\s*reverse_proxy\s+127\.0\.0\.1:8788\s*$/m.test(text)) throw new Error('Caddy host or proxy');
  command('caddy', ['validate', '--config', caddyfile, '--adapter', 'caddyfile']); // caddy validate
}

function checkMarkerDbPersistence(deployment) {
  const loop = file('collector/loop.js');
  const collector = file('deploy/aoying-collector.service');
  if (!loop.includes("/var/lib/aoying-monitor/collector-backfill-complete") || !collector.includes('ReadWritePaths=/var/lib/aoying-monitor')) {
    throw new Error('marker storage');
  }
  if (staticMode) return;
  const dbPath = resolve(deployment.env.DB_PATH);
  if (!existsSync(markerPath) || !existsSync(dbPath) || !markerPath.startsWith(`${dataDir}/`) || !dbPath.startsWith(`${dataDir}/`)) throw new Error('marker/database missing');
  if (statSync(markerPath).dev !== statSync(dbPath).dev) throw new Error('marker/database device mismatch');
}

function checkSecretLeakage() {
  const setup = file('deploy/configure-vless.sh');
  if (!setup.includes('read -rsp') || setup.includes('echo $VLESS_URI')) throw new Error('unsafe setup script');
  if (staticMode) return;
  const unitInfo = command('systemctl', ['show', 'sing-box', 'aoying-monitor', 'aoying-collector', '--property=Environment', '--property=ExecStart']);
  const processArgs = command('ps', ['-eo', 'args=']);
  const recentLogs = command('journalctl', ['-u', 'sing-box', '-u', 'aoying-monitor', '-u', 'aoying-collector', '--since=-10 minutes', '--no-pager']);
  if (secretPattern.test(unitInfo) || secretPattern.test(processArgs) || secretPattern.test(recentLogs)) throw new Error('secret found');
}

function checkLocalWebCollector(deployment) {
  const main = file('collector/main.js');
  const config = file('collector/config.js');
  if (!main.includes('god_of_trader_tony') || !config.includes('127.0.0.1:8788') || !config.includes('127.0.0.1:1080')) throw new Error('local collector wiring');
  if (staticMode) return;
  command('curl', ['-fsS', '--max-time', '15', '127.0.0.1:8788/', '--output', '/dev/null']);
  const page = command('curl', ['--socks5-hostname', '127.0.0.1:1080', '-fsS', '--max-time', '30', 'https://www.binance.com/zh-CN/square/profile/god_of_trader_tony']);
  if (!page.trim() || blockPattern.test(page) || !binanceProfilePattern.test(page) || !binanceTradePattern.test(page) || !binancePricePattern.test(page)) throw new Error('proxy probe');
  const db = new DatabaseSync(resolve(deployment.env.DB_PATH), { readOnly: true });
  try {
    const heartbeat = db.prepare('SELECT observed_at FROM heartbeats ORDER BY observed_at DESC LIMIT 1').get()?.observed_at;
    const duplicate = db.prepare('SELECT event_id FROM events GROUP BY event_id HAVING COUNT(*) > 1 LIMIT 1').get();
    const heartbeatTime = Date.parse(heartbeat);
    const heartbeatAge = Date.now() - heartbeatTime;
    if (!Number.isFinite(heartbeatTime) || heartbeatAge < 0 || heartbeatAge > 60_000 || duplicate) throw new Error('collector state');
  } finally {
    db.close();
  }
}

function run(name, check) {
  try {
    check();
    process.stdout.write(`${name} PASS\n`);
    return true;
  } catch {
    process.stdout.write(`${name} FAIL\n`);
    return false;
  }
}

if (!staticMode && !liveMode) {
  process.stdout.write('arguments FAIL\n');
  process.exitCode = 1;
} else {
  const results = [];
  results.push(run('node24', checkNode24));
  results.push(run('systemd_hardening', checkSystemdHardening));
  results.push(run('socks_loopback', checkSocksLoopback));
  results.push(run('services', checkServices));
  let deployment = null;
  results.push(run('environment_permissions', () => { deployment = checkEnvironment(); }));
  results.push(run('sslip_caddy', checkSslipCaddy));
  results.push(run('marker_db_persistence', () => checkMarkerDbPersistence(deployment)));
  results.push(run('secret_leakage', checkSecretLeakage));
  results.push(run('local_web_collector', () => checkLocalWebCollector(deployment)));
  if (results.some(result => !result)) process.exitCode = 1;
}
