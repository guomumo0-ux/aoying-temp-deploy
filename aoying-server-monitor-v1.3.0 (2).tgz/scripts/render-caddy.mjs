import { readFileSync, writeFileSync } from 'node:fs';
import { isValidSslipHost } from './sslip-host.mjs';
const args = {}; for (let i = 2; i < process.argv.length; i += 1) if (process.argv[i].startsWith('--')) args[process.argv[i].slice(2)] = process.argv[i + 1];
const ip = args.ip;
const host = args.host ?? (ip && ip.split('.').length === 4 ? `${ip.replaceAll('.', '-')}.sslip.io` : null);
if (!isValidSslipHost(host)) { console.error('Provide --ip <public IPv4> or --host <dashed-ip>.sslip.io'); process.exit(1); }
if (!args.output) { console.error('Provide --output <Caddyfile>'); process.exit(1); }
const template = readFileSync(new URL('../deploy/Caddyfile.example', import.meta.url), 'utf8');
writeFileSync(args.output, template.replace('<public-ip-with-dashes>.sslip.io', host), { mode: 0o600 });
