#!/bin/sh
set -eu
node_bin="${1:-/usr/bin/node}"
major="$($node_bin -p "process.versions.node.split('.')[0]")"
[ "$major" = 24 ] || { echo "Node major 24 required" >&2; exit 1; }
