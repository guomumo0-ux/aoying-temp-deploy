export function isValidSslipHost(host) {
  const match = /^((?:\d+-){3}\d+)\.sslip\.io$/.exec(String(host ?? ''));
  if (!match) return false;
  const octets = match[1].split('-');
  return octets.every(value => /^(?:0|[1-9]\d*)$/.test(value) && Number(value) <= 255);
}
