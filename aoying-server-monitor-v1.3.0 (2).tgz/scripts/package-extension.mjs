import { mkdir, rm, readFile, writeFile } from 'node:fs/promises';
import { join, relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
const exec = promisify(execFile);
const project = join(dirname(fileURLToPath(import.meta.url)), '..');
const staging = join(project, 'dist', 'extension-staging');
const zip = join(project, 'dist', 'aoying-monitor-extension.zip');
const files = ['extension/manifest.json','extension/background.js','extension/popup.html','extension/popup.js','extension/popup.css','extension/content/loader.js','extension/content/collector.js','extension/content/parser.js','extension/content/backfill.js','shared/contracts.js','shared/normalize.js','shared/fingerprint.js'];
await rm(staging, { recursive: true, force: true }); await mkdir(staging, { recursive: true }); await rm(zip, { force: true });
for (const file of files) { const packagePath = file === 'extension/manifest.json' ? 'manifest.json' : relative(project, file); const target = join(staging, packagePath); await mkdir(dirname(target), { recursive: true }); let data = await readFile(join(project, file)); if (file === 'extension/manifest.json') { const manifest = JSON.parse(data); manifest.background.service_worker = 'extension/background.js'; manifest.action.default_popup = 'extension/popup.html'; manifest.content_scripts[0].js = ['extension/content/loader.js']; manifest.web_accessible_resources[0].resources = ['extension/content/collector.js','extension/content/parser.js','extension/content/backfill.js','shared/contracts.js','shared/normalize.js','shared/fingerprint.js']; data = JSON.stringify(manifest); } await writeFile(target, data); }
await exec('zip', ['-qr', zip, '.'], { cwd: staging });
console.log(`created ${zip}`);
