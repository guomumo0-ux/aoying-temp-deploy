export const HISTORY_WINDOW_MS = 48 * 60 * 60 * 1000;

export function hasReachedHistoryCutoff(events, now = Date.now()) {
  const cutoff = now - HISTORY_WINDOW_MS;
  return events.some(event => Number.isFinite(Date.parse(event.tradeTime)) && Date.parse(event.tradeTime) <= cutoff);
}

function normalizedText(element) {
  return String(element?.textContent ?? '').replace(/\s+/g, ' ').trim();
}

function findLatestTradesTab(document) {
  return [...document.querySelectorAll('[role="tab"],button,a')]
    .filter(element => normalizedText(element).includes('最新交易记录'))
    .sort((a, b) => normalizedText(a).length - normalizedText(b).length)[0] ?? null;
}

function findScroller(document) {
  const candidates = [document.scrollingElement, ...document.querySelectorAll('main,section,div,ul')].filter(Boolean);
  return candidates
    .filter(element => Number(element.scrollHeight) > Number(element.clientHeight) + 40)
    .sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight))[0] ?? null;
}

function advanceScroller(document) {
  const scroller = findScroller(document);
  if (!scroller) return false;
  const before = Number(scroller.scrollTop) || 0;
  const maximum = Math.max(0, Number(scroller.scrollHeight) - Number(scroller.clientHeight));
  scroller.scrollTop = Math.min(maximum, before + Math.max(80, Number(scroller.clientHeight) * 0.8));
  return scroller.scrollTop > before;
}

export async function backfillHistory({ document, read, emit, wait = ms => new Promise(resolve => setTimeout(resolve, ms)), now = Date.now, maxSteps = 60 }) {
  const tab = findLatestTradesTab(document);
  if (!tab) return { state: 'tab_not_found', pages: 0 };
  tab.click();
  await wait(1500);
  let pages = 0;
  for (let step = 0; step < maxSteps; step += 1) {
    const payload = read();
    if (payload) { emit(payload); pages += 1; }
    if (payload?.historyCutoffReached || (payload?.events?.length && hasReachedHistoryCutoff(payload.events, now()))) return { state: 'cutoff_reached', pages };
    if (!advanceScroller(document)) return { state: 'end_reached', pages };
    await wait(1200);
  }
  return { state: 'step_limit', pages };
}
