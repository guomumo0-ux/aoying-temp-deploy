import { fingerprintEvent, sha256Text } from '../../shared/fingerprint.js';
import { normalizeAction, normalizeSide, parseDecimal } from '../../shared/normalize.js';

const PARSER_VERSION = '2';
const EMPTY_TEXT = /^(?:暂无持仓|暂无交易记录|暂无交易|暂无成交记录|暂无成交)$/;
const TIME_LINE = /^(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})(?:\s+(.+))?$/;
const DETAIL_LINE = /以均价为(?<price>.+?)(?<action>开启|开仓|关闭|平仓|加仓|减仓)(?<side>做多|做空)(?<symbol>[A-Z][A-Z0-9]{2,20})\s*永续仓位(?:，成交数量为(?<quantity>[^A-Z，。\s]+)[A-Z0-9]*)?(?:，总价值为(?<notional>[^A-Z，。\s]+)USDT)?/;
const POSITION_LINE = /(?<symbol>[A-Z][A-Z0-9]{2,20})\s*(?<side>做多|做空|多|空)[^\n]*(?:数量|持仓量)[：:\s]*(?<quantity>[-+\d,.]+)[^\d\n]*(?:开仓均价|均价)[：:\s]*(?<entryPrice>[-+\d,.]+)/;

function isoTradeTime(date, time) {
  return `${date}T${time}:00Z`;
}

function numberOrNull(value) {
  return value && !/未显示|未知|--/.test(value) ? parseDecimal(value) : null;
}

function parseRecord(date, time, detail, rawText) {
  const match = detail.match(DETAIL_LINE);
  if (!match) return null;
  const event = {
    symbol: match.groups.symbol,
    side: normalizeSide(match.groups.side),
    action: normalizeAction(match.groups.action),
    price: numberOrNull(match.groups.price),
    quantity: numberOrNull(match.groups.quantity),
    notionalUsdt: numberOrNull(match.groups.notional),
    tradeTime: isoTradeTime(date, time),
    rawTextHash: sha256Text(rawText)
  };
  const eventId = fingerprintEvent(event);
  return { ...event, event_id: eventId };
}

function parsePosition(line) {
  const match = line.match(POSITION_LINE);
  if (!match) return null;
  const { symbol, side, quantity, entryPrice } = match.groups;
  const normalizedSide = normalizeSide(side);
  const numericQuantity = parseDecimal(quantity);
  const numericEntry = parseDecimal(entryPrice);
  if (normalizedSide === 'unknown' || numericQuantity === null || numericEntry === null) return null;
  return { position_id: `${symbol}:${normalizedSide}`, symbol, side: normalizedSide, quantity: numericQuantity, entryPrice: numericEntry };
}

export function parseVisibleText(text, observedAt) {
  const source = String(text ?? '').replaceAll('\r', '').trim();
  const base = { parserVersion: PARSER_VERSION, events: [], positions: [] };
  if (!source) return { ...base, status: 'parse_error' };
  if (source.split('\n').some(line => EMPTY_TEXT.test(line.trim()))) return { ...base, status: 'empty' };

  const lines = source.split('\n').map(line => line.trim()).filter(Boolean);
  const events = [];
  const positions = [];
  for (let index = 0; index < lines.length; index += 1) {
    const header = lines[index].match(TIME_LINE);
    if (!header || !lines[index + 1]) continue;
    const detail = lines[index + 1];
    const event = parseRecord(header[1], header[2], detail, `${lines[index]}\n${detail}`);
    if (event) events.push(event);
    const position = parsePosition(lines[index]);
    if (position) positions.push(position);
  }
  for (const line of lines) { const position = parsePosition(line); if (position) positions.push(position); }

  const unique = [...new Map(events.map(event => [event.event_id, event])).values()];
  const uniquePositions = [...new Map(positions.map(position => [position.position_id, position])).values()];
  if (!unique.length && !uniquePositions.length) return { ...base, status: 'parse_error', observedAt };
  return { ...base, status: 'ok', observedAt, events: unique, positions: uniquePositions };
}
