# 阿里云服务器监控快速部署

本程序只读取币安广场公开页面，不会下单或跟单。服务器必须能通过已授权的住宅代理正常打开目标页面，否则无法采集。

## 功能

- 每 10 秒检查 `god_of_trader_tony` 的公开交易记录。
- 首次启动回填近 48 小时记录，但不发送历史消息轰炸。
- 后续仅对新发现的交易去重入库并发送 Telegram。
- 页面被拦截、要求登录、出现验证码或内容为空时，不生成虚假交易。
- 代理仅监听 `127.0.0.1:1080`，网页服务仅监听 `127.0.0.1:8788`。

## 安装顺序

1. 把压缩包上传到服务器并解压到 `/opt/aoying-monitor`。
2. 安装 Node.js 24、Caddy、sing-box，并在项目目录运行 `npm ci --omit=dev` 和 `npx playwright install --with-deps chromium`。
3. 复制 `deploy/env.example` 到 `/etc/aoying-monitor/aoying-monitor.env`，填写现有的 Telegram Bot Token、Chat ID、后台密码哈希及随机 `INGEST_TOKEN`，权限设为 `0600`。
4. 运行 `sudo deploy/configure-vless.sh`，在隐藏提示符中输入已经重置的 VLESS Reality 地址。
5. 安装 `deploy/` 下的三个 systemd 配置，先运行 `node scripts/verify-deployment.mjs --static`。
6. 静态检查通过后再启用 `sing-box`、`aoying-monitor`、`aoying-collector`，最后运行 `sudo node scripts/verify-deployment.mjs`。

详细命令、安全边界、故障排查和回滚方式见 `README.md`。

## 验收

运行：

```bash
systemctl is-active sing-box aoying-monitor aoying-collector
journalctl -u aoying-collector -n 30 --no-pager
```

三个服务均应显示 `active`。目标页面可访问后，网站应出现新心跳；只有后续新增交易才会触发 Telegram 通知。
