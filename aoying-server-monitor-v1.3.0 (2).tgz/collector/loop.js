import { access, mkdir, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';

const DEFAULT_INTERVALS = [10_000, 30_000, 60_000, 300_000];
const DEFAULT_MARKER_PATH = '/var/lib/aoying-monitor/collector-backfill-complete';
const SOURCE_ID = 'binance-god_of_trader_tony';
const PARSER_VERSION = '2';

function defaultSleep(ms, signal) {
  return new Promise(resolve => {
    let timer;
    const finish = () => {
      clearTimeout(timer);
      signal?.removeEventListener?.('abort', finish);
      resolve();
    };
    if (signal?.aborted) return finish();
    timer = setTimeout(finish, ms);
    signal?.addEventListener?.('abort', finish, { once: true });
  });
}

function currentIso(clock) {
  const value = typeof clock === 'function' ? clock() : clock?.now?.();
  if (value instanceof Date) return value.toISOString();
  if (typeof value === 'string' && Number.isFinite(Date.parse(value))) return value;
  if (typeof value === 'number' && Number.isFinite(value)) return new Date(value).toISOString();
  return new Date().toISOString();
}

function statusForPage(pageState, payload) {
  if (pageState === 'valid' && usablePayload(payload)) return 'ok';
  if (pageState === 'parse_error' || pageState === 'empty' || pageState === 'unknown' || pageState === 'valid') return 'parse_error';
  if (pageState === 'proxy_error') return 'proxy_error';
  if (pageState === 'blocked' || pageState === 'captcha' || pageState === 'login_wall') return 'blocked';
  return 'proxy_error';
}

function usablePayload(payload) {
  return Boolean(payload) &&
    (payload.status === undefined || payload.status === 'ok') &&
    typeof payload.parserVersion === 'string' && payload.parserVersion.length > 0 &&
    Array.isArray(payload.events) && Array.isArray(payload.positions);
}

function ingestPayload({ payload, status, observedAt }) {
  return {
    heartbeat: {
      sourceId: SOURCE_ID,
      observedAt,
      parserVersion: usablePayload(payload) ? payload.parserVersion : PARSER_VERSION,
      status,
    },
    events: status === 'ok' && usablePayload(payload) ? payload.events : [],
    positions: status === 'ok' && usablePayload(payload) ? payload.positions : [],
  };
}

async function markerExists(markerPath) {
  try {
    await access(markerPath);
    return true;
  } catch (error) {
    if (error?.code === 'ENOENT') return false;
    throw error;
  }
}

async function markBackfillComplete(markerPath) {
  await mkdir(dirname(markerPath), { recursive: true });
  await writeFile(markerPath, 'complete\n', 'utf8');
}

function completeBackfill(result) {
  return result?.state === 'cutoff_reached' || result?.state === 'step_limit';
}

function validIntervals(intervals) {
  if (!Array.isArray(intervals) || !intervals.length || intervals.some(value => !Number.isFinite(value) || value < 0)) {
    return DEFAULT_INTERVALS;
  }
  return intervals;
}

export function createCollectorLoop({
  browser,
  ingest,
  clock = () => new Date().toISOString(),
  sleep = defaultSleep,
  intervals = DEFAULT_INTERVALS,
  markerPath = DEFAULT_MARKER_PATH,
} = {}) {
  const delays = validIntervals(intervals);
  let activeRun = null;

  async function sendHeartbeat(status, payload, observedAt, signal) {
    if (signal?.aborted) return false;
    await ingest.send(ingestPayload({ payload, status, observedAt }), { signal });
    return !signal?.aborted;
  }

  async function activateNotifications(signal) {
    if (signal?.aborted) return false;
    if (typeof ingest.activate !== 'function') throw new Error('activation_not_supported');
    await ingest.activate({ signal });
    return !signal?.aborted;
  }

  async function cycle(signal) {
    if (signal?.aborted) return false;
    const observedAt = currentIso(clock);
    let snapshot;
    try {
      snapshot = await browser.read(observedAt);
    } catch {
      if (signal?.aborted) return false;
      try {
        await sendHeartbeat('proxy_error', null, observedAt, signal);
      } catch {
        // A failed heartbeat is still a failed cycle; do not expose dependency errors.
      }
      return false;
    }

    if (signal?.aborted) return false;
    const pageState = snapshot?.pageState?.state;
    const status = statusForPage(pageState, snapshot?.payload);
    if (status !== 'ok') {
      try {
        await sendHeartbeat(status, snapshot?.payload, observedAt, signal);
      } catch {
        // The next loop iteration retries a heartbeat that could not be delivered.
      }
      return false;
    }

    try {
      if (await markerExists(markerPath)) {
        if (signal?.aborted || !await activateNotifications(signal)) return false;
        return await sendHeartbeat('ok', snapshot.payload, observedAt, signal);
      }
      if (signal?.aborted) return false;
      const result = await browser.backfill({
        emit: async historyPayload => {
          if (signal?.aborted) throw new Error('collector_aborted');
          if (!usablePayload(historyPayload)) throw new Error('invalid_backfill_payload');
          if (!await sendHeartbeat('ok', historyPayload, observedAt, signal)) throw new Error('collector_aborted');
        },
      });
      if (signal?.aborted) return false;
      if (!completeBackfill(result)) return false;
      if (!await sendHeartbeat('ok', snapshot.payload, observedAt, signal)) return false;
      if (!await activateNotifications(signal)) return false;
      if (signal?.aborted) return false;
      await markBackfillComplete(markerPath);
      return true;
    } catch {
      return false;
    }
  }

  async function runUntilAborted(signal) {
    let failureIndex = 0;
    while (!signal?.aborted) {
      const succeeded = await cycle(signal);
      const delay = succeeded ? delays[0] : delays[Math.min(failureIndex, delays.length - 1)];
      failureIndex = succeeded ? 0 : Math.min(failureIndex + 1, delays.length - 1);
      if (signal?.aborted) break;
      await sleep(delay, signal);
    }
  }

  return {
    run(signal) {
      if (activeRun) return activeRun;
      activeRun = runUntilAborted(signal).finally(() => { activeRun = null; });
      return activeRun;
    },
  };
}
