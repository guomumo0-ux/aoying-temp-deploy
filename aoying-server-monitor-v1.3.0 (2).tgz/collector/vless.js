const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function requiredParameter(params, name) {
  const value = params.get(name);
  if (!value) throw new Error(`VLESS link requires ${name}`);
  return value;
}

function explicitPort(uri, url) {
  const authority = uri.slice(uri.indexOf('//') + 2).split(/[?#]/, 1)[0];
  const host = authority.slice(authority.lastIndexOf('@') + 1);
  const portText = host.startsWith('[')
    ? host.slice(host.indexOf(']') + 1).replace(/^:/, '')
    : host.slice(host.lastIndexOf(':') + 1);
  if (!/^\d+$/.test(portText)) throw new Error('VLESS link requires an explicit port');
  const port = Number(portText);
  if (!Number.isInteger(port) || port < 1 || port > 65535 || url.port && Number(url.port) !== port) {
    throw new Error('VLESS link has an invalid port');
  }
  return port;
}

export function parseVlessReality(uri) {
  if (typeof uri !== 'string') throw new TypeError('VLESS link must be a string');

  let url;
  try {
    url = new URL(uri);
  } catch {
    throw new Error('Invalid VLESS link');
  }
  if (url.protocol !== 'vless:' || !url.hostname || url.password) {
    throw new Error('Unsupported VLESS link');
  }

  const uuid = decodeURIComponent(url.username);
  if (!UUID_PATTERN.test(uuid)) throw new Error('VLESS link has an invalid UUID');
  const params = url.searchParams;
  if (requiredParameter(params, 'encryption') !== 'none' ||
      requiredParameter(params, 'security') !== 'reality' ||
      requiredParameter(params, 'type') !== 'tcp') {
    throw new Error('Unsupported VLESS link');
  }

  const serverPort = explicitPort(uri, url);
  return {
    uuid,
    server: url.hostname,
    serverPort,
    serverName: requiredParameter(params, 'sni'),
    fingerprint: requiredParameter(params, 'fp'),
    publicKey: requiredParameter(params, 'pbk'),
    shortId: requiredParameter(params, 'sid')
  };
}

export function toSingBoxConfig(config) {
  return {
    log: { level: 'warn' },
    inbounds: [{
      type: 'socks',
      tag: 'aoying-socks',
      listen: '127.0.0.1',
      listen_port: 1080
    }],
    outbounds: [{
      type: 'vless',
      tag: 'aoying-vless',
      server: config.server,
      server_port: config.serverPort,
      uuid: config.uuid,
      tls: {
        enabled: true,
        server_name: config.serverName,
        utls: {
          enabled: true,
          fingerprint: config.fingerprint
        },
        reality: {
          enabled: true,
          public_key: config.publicKey,
          short_id: config.shortId
        }
      }
    }]
  };
}
