const BLOCKED_MARKERS = /403 ERROR|Request blocked|request could not be satisfied|Access Denied/i;
const CAPTCHA_MARKERS = /Verify you are human|Checking your browser|unusual traffic|安全验证/i;
const LOGIN_MARKERS = /登录后查看|Log in to view|Sign in/i;

export function classifyPage({ text = '', url } = {}) {
  void url;
  const pageText = typeof text === 'string' ? text : String(text ?? '');

  if (!pageText.trim()) return { state: 'empty', reason: 'page text is empty' };
  if (BLOCKED_MARKERS.test(pageText)) return { state: 'blocked', reason: 'blocked-page marker detected' };
  if (CAPTCHA_MARKERS.test(pageText)) return { state: 'captcha', reason: 'verification-page marker detected' };
  if (LOGIN_MARKERS.test(pageText)) return { state: 'login_wall', reason: 'login-page marker detected' };
  if (pageText.includes('最新交易记录') && pageText.includes('以均价为')) {
    return { state: 'valid', reason: 'required trade markers found' };
  }
  return { state: 'unknown', reason: 'required trade markers missing' };
}
