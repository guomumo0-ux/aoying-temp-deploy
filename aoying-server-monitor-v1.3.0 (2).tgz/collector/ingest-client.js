const INGEST_PATH = '/api/v1/ingest';

export function createIngestClient({ apiUrl, token, fetchFn = globalThis.fetch } = {}) {
  const endpoint = `${String(apiUrl).replace(/\/+$/, '')}${INGEST_PATH}`;

  async function post(url, body, signal) {
    let response;
    let status;
    try {
      response = await fetchFn(url, {
        method: 'POST',
        headers: {
          authorization: `Bearer ${token}`,
          'content-type': 'application/json',
        },
        body,
        signal,
      });

      if (response?.ok) return;

      status = response?.status;
      if (!Number.isInteger(status) || status < 100 || status > 599) {
        throw new Error('invalid response status');
      }
    } catch {
      throw new Error('ingest_network_error');
    }

    throw new Error(`ingest_http_${status}`);
  }

  return {
    async send(payload, { signal } = {}) {
      return post(endpoint, JSON.stringify(payload), signal);
    },

    async activate({ signal } = {}) {
      return post(`${endpoint}/activate`, undefined, signal);
    },
  };
}
