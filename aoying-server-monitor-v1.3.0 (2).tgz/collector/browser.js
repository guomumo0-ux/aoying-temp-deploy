import { hasReachedHistoryCutoff } from '../extension/content/backfill.js';
import { parseVisibleText } from '../extension/content/parser.js';
import { classifyPage } from './page-state.js';

const LOOPBACK_SOCKS_URL = 'socks5://127.0.0.1:1080';
const PUBLIC_PROFILE_URL = 'https://www.binance.com/zh-CN/square/profile/god_of_trader_tony';
const NAVIGATION_OPTIONS = { waitUntil: 'domcontentloaded', timeout: 30_000 };
const MAX_BACKFILL_STEPS = 60;

function configurationIsSafe({ chromium, proxyUrl, profileUrl }) {
  return chromium && typeof chromium.launch === 'function' &&
    proxyUrl === LOOPBACK_SOCKS_URL && profileUrl === PUBLIC_PROFILE_URL;
}

function genericError(code) {
  return new Error(code);
}

function nowIso() {
  return new Date().toISOString();
}

async function clickLatestTrades(page) {
  let candidates;
  try {
    candidates = page.locator('[role="tab"], button, a');
    const count = await candidates.count();
    let selected = null;
    for (let index = 0; index < count; index += 1) {
      const candidate = candidates.nth(index);
      const text = (await candidate.innerText()).replace(/\s+/g, ' ').trim();
      if (text.includes('最新交易记录') && (!selected || text.length < selected.text.length)) {
        selected = { candidate, text };
      }
    }
    if (!selected) return false;
    await selected.candidate.click();
    await page.waitForTimeout(1500);
    return true;
  } catch {
    throw genericError('browser_interaction_error');
  }
}

function backfillLimit(maxSteps) {
  if (maxSteps === undefined) return MAX_BACKFILL_STEPS;
  if (!Number.isInteger(maxSteps)) throw genericError('browser_config_error');
  return Math.min(Math.max(maxSteps, 0), MAX_BACKFILL_STEPS);
}

export async function createBinanceBrowser(options = {}) {
  if (!configurationIsSafe(options)) throw genericError('browser_config_error');

  let browser;
  let page;
  try {
    browser = await options.chromium.launch({ headless: true, proxy: { server: options.proxyUrl } });
    page = await browser.newPage();
  } catch {
    try { await browser?.close(); } catch { /* preserve generic launch failure */ }
    throw genericError('browser_launch_error');
  }

  let navigated = false;

  async function ensureProfile() {
    if (navigated) return;
    try {
      await page.goto(options.profileUrl, NAVIGATION_OPTIONS);
      navigated = true;
    } catch {
      throw genericError('browser_navigation_error');
    }
  }

  async function read(readNowIso = nowIso()) {
    await ensureProfile();
    let text;
    try {
      text = await page.locator('body').innerText();
    } catch {
      throw genericError('browser_read_error');
    }

    const pageState = classifyPage({ text, url: options.profileUrl });
    if (pageState.state !== 'valid') return { pageState, payload: null };

    let payload;
    try {
      payload = parseVisibleText(text, readNowIso);
    } catch {
      throw genericError('browser_parse_error');
    }
    if (payload.status !== 'ok') {
      const state = payload.status === 'empty' ? 'empty' : 'parse_error';
      return { pageState: { state, reason: 'visible trade records did not parse' }, payload: null };
    }
    return { pageState, payload };
  }

  return {
    async read(readNowIso) {
      return read(readNowIso);
    },

    async backfill({ emit, maxSteps } = {}) {
      if (typeof emit !== 'function') throw genericError('browser_config_error');
      const limit = backfillLimit(maxSteps);
      await ensureProfile();
      if (!await clickLatestTrades(page)) return { state: 'tab_not_found', pages: 0 };

      let pages = 0;
      for (let step = 0; step < limit; step += 1) {
        const result = await read();
        if (!result.payload) return { state: result.pageState.state, pages };

        try {
          await emit(result.payload);
        } catch {
          throw genericError('browser_emit_error');
        }
        pages += 1;
        if (hasReachedHistoryCutoff(result.payload.events)) return { state: 'cutoff_reached', pages };

        try {
          await page.mouse.wheel(0, 800);
          await page.waitForTimeout(1200);
        } catch {
          throw genericError('browser_interaction_error');
        }
      }
      return { state: 'step_limit', pages };
    },

    async close() {
      try {
        await browser.close();
      } catch {
        throw genericError('browser_close_error');
      }
    }
  };
}
