const DEFAULT_API_URL = 'http://127.0.0.1:8788';
const DEFAULT_PROXY_URL = 'socks5://127.0.0.1:1080';
const DEFAULT_POLL_MS = 10_000;

function loopbackUrl(value, expected, key) {
  if (typeof value !== 'string' || value !== expected) {
    throw new Error(`${key} must use the loopback collector endpoint`);
  }

  const parsed = new URL(value);
  const allowed = new URL(expected);
  if (parsed.protocol !== allowed.protocol || parsed.hostname !== '127.0.0.1' || parsed.port !== allowed.port ||
    parsed.username || parsed.password || parsed.pathname !== allowed.pathname || parsed.search || parsed.hash) {
    throw new Error(`${key} must use the loopback collector endpoint`);
  }

  return value;
}

export function loadCollectorConfig(env = process.env) {
  const token = env.INGEST_TOKEN;
  if (typeof token !== 'string' || !/^[0-9a-f]{64}$/i.test(token)) {
    throw new Error('INGEST_TOKEN must be a 64-character hexadecimal token');
  }

  return {
    ingestToken: token,
    apiUrl: loopbackUrl(env.COLLECTOR_API_URL ?? DEFAULT_API_URL, DEFAULT_API_URL, 'COLLECTOR_API_URL'),
    proxyUrl: loopbackUrl(env.COLLECTOR_PROXY_URL ?? DEFAULT_PROXY_URL, DEFAULT_PROXY_URL, 'COLLECTOR_PROXY_URL'),
    pollMs: DEFAULT_POLL_MS,
  };
}
