import { chromium } from 'playwright';

import { createBinanceBrowser } from './browser.js';
import { loadCollectorConfig } from './config.js';
import { createIngestClient } from './ingest-client.js';
import { createCollectorLoop } from './loop.js';

const PROFILE_URL = 'https://www.binance.com/zh-CN/square/profile/god_of_trader_tony';
const BACKOFF_INTERVALS = [10_000, 30_000, 60_000, 300_000];

export async function runCollector({
  env = process.env,
  processLike = process,
  dependencies = {},
} = {}) {
  const config = loadCollectorConfig(env);
  const controller = new AbortController();
  const createBrowser = dependencies.createBrowser ?? createBinanceBrowser;
  const createIngest = dependencies.createIngestClient ?? createIngestClient;
  const createLoop = dependencies.createLoop ?? createCollectorLoop;
  const browserEngine = dependencies.chromium ?? chromium;
  let browser;
  let closePromise;

  function closeBrowser() {
    if (!browser) return Promise.resolve();
    if (!closePromise) {
      try {
        closePromise = Promise.resolve(browser.close());
      } catch {
        closePromise = Promise.resolve();
      }
      closePromise = closePromise.catch(() => {});
    }
    return closePromise;
  }

  const stop = () => {
    controller.abort();
    void closeBrowser();
  };

  processLike.once('SIGTERM', stop);
  processLike.once('SIGINT', stop);

  try {
    browser = await createBrowser({
      chromium: browserEngine,
      proxyUrl: config.proxyUrl,
      profileUrl: PROFILE_URL,
    });
    if (controller.signal.aborted) return;

    const ingest = createIngest({ apiUrl: config.apiUrl, token: config.ingestToken });
    const loop = createLoop({
      browser,
      ingest,
      intervals: [config.pollMs, ...BACKOFF_INTERVALS.slice(1)],
    });
    await loop.run(controller.signal);
  } finally {
    processLike.removeListener('SIGTERM', stop);
    processLike.removeListener('SIGINT', stop);
    await closeBrowser();
  }
}

if (import.meta.main) {
  runCollector().catch(() => {
    process.stderr.write('collector_runtime_error\n');
    process.exitCode = 1;
  });
}
